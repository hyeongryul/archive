# Copyright 2018 The HuggingFace Inc. team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Auto Model class."""

import os
from collections import OrderedDict
from typing import TYPE_CHECKING

from ...utils import logging
from .auto_factory import (
    _BaseAutoBackboneClass,
    _BaseAutoModelClass,
    _LazyAutoMapping,
    auto_class_update,
)
from .configuration_auto import CONFIG_MAPPING_NAMES


if TYPE_CHECKING:
    from ...generation import GenerationMixin
    from ...modeling_utils import PreTrainedModel

    # class for better type annotations
    class _BaseModelWithGenerate(PreTrainedModel, GenerationMixin):
        pass


logger = logging.get_logger(__name__)

MODEL_MAPPING_NAMES = OrderedDict(
    [
        # Base model mapping
        ("afmoe", "AfmoeModel"),
        ("aimv2", "Aimv2Model"),
        ("aimv2_vision_model", "Aimv2VisionModel"),
        ("albert", "AlbertModel"),
        ("align", "AlignModel"),
        ("altclip", "AltCLIPModel"),
        ("apertus", "ApertusModel"),
        ("arcee", "ArceeModel"),
        ("aria", "AriaModel"),
        ("aria_text", "AriaTextModel"),
        ("audio-spectrogram-transformer", "ASTModel"),
        ("audioflamingo3", "AudioFlamingo3Model"),
        ("audioflamingo3_encoder", "AudioFlamingo3Encoder"),
        ("autoformer", "AutoformerModel"),
        ("axk1", "AXK1Model"),
        ("axk2", "AXK2Model"),
        ("aya_vision", "AyaVisionModel"),
        ("bailing_hybrid", "BailingHybridModel"),
        ("bamba", "BambaModel"),
        ("bark", "BarkModel"),
        ("bart", "BartModel"),
        ("beam", "BeamModel"),
        ("beit", "BeitModel"),
        ("bert", "BertModel"),
        ("bert-generation", "BertGenerationEncoder"),
        ("big_bird", "BigBirdModel"),
        ("bigbird_pegasus", "BigBirdPegasusModel"),
        ("biogpt", "BioGptModel"),
        ("bit", "BitModel"),
        ("bitnet", "BitNetModel"),
        ("blenderbot", "BlenderbotModel"),
        ("blenderbot-small", "BlenderbotSmallModel"),
        ("blip", "BlipModel"),
        ("blip-2", "Blip2Model"),
        ("blip_2_qformer", "Blip2QFormerModel"),
        ("bloom", "BloomModel"),
        ("blt", "BltModel"),
        ("bridgetower", "BridgeTowerModel"),
        ("bros", "BrosModel"),
        ("camembert", "CamembertModel"),
        ("canary", "CanaryModel"),
        ("canine", "CanineModel"),
        ("chameleon", "ChameleonModel"),
        ("chinese_clip", "ChineseCLIPModel"),
        ("chinese_clip_vision_model", "ChineseCLIPVisionModel"),
        ("clap", "ClapModel"),
        ("clip", "CLIPModel"),
        ("clip_text_model", "CLIPTextModel"),
        ("clip_vision_model", "CLIPVisionModel"),
        ("clipseg", "CLIPSegModel"),
        ("clvp", "ClvpModelForConditionalGeneration"),
        ("codegen", "CodeGenModel"),
        ("cohere", "CohereModel"),
        ("cohere2", "Cohere2Model"),
        ("cohere2_moe", "Cohere2MoeModel"),
        ("cohere2_vision", "Cohere2VisionModel"),
        ("cohere_asr", "CohereAsrModel"),
        ("cohere_compass", "CohereCompassModel"),
        ("cohere_compass_text", "CohereCompassTextModel"),
        ("cohere_compass_vision", "CohereCompassVisionModel"),
        ("conditional_detr", "ConditionalDetrModel"),
        ("convbert", "ConvBertModel"),
        ("convnext", "ConvNextModel"),
        ("convnextv2", "ConvNextV2Model"),
        ("cosmos3_edge", "Cosmos3EdgeModel"),
        ("cosmos3_edge_text", "Cosmos3EdgeTextModel"),
        ("cosmos3_edge_vision", "Cosmos3EdgeVisionModel"),
        ("cosmos3_omni", "Cosmos3OmniModel"),
        ("cpmant", "CpmAntModel"),
        ("csm", "CsmForConditionalGeneration"),
        ("ctrl", "CTRLModel"),
        ("cvt", "CvtModel"),
        ("cwm", "CwmModel"),
        ("d_fine", "DFineModel"),
        ("dab-detr", "DabDetrModel"),
        ("dac", "DacModel"),
        ("data2vec-audio", "Data2VecAudioModel"),
        ("data2vec-text", "Data2VecTextModel"),
        ("data2vec-vision", "Data2VecVisionModel"),
        ("dbrx", "DbrxModel"),
        ("deberta", "DebertaModel"),
        ("deberta-v2", "DebertaV2Model"),
        ("decision_transformer", "DecisionTransformerModel"),
        ("deepseek_ocr2", "DeepseekOcr2Model"),
        ("deepseek_v2", "DeepseekV2Model"),
        ("deepseek_v3", "DeepseekV3Model"),
        ("deepseek_v32", "DeepseekV32Model"),
        ("deepseek_v4", "DeepseekV4Model"),
        ("deepseek_vl", "DeepseekVLModel"),
        ("deepseek_vl_hybrid", "DeepseekVLHybridModel"),
        ("deformable_detr", "DeformableDetrModel"),
        ("deimv2", "Deimv2Model"),
        ("deit", "DeiTModel"),
        ("depth_pro", "DepthProModel"),
        ("detr", "DetrModel"),
        ("dia", "DiaModel"),
        ("diffllama", "DiffLlamaModel"),
        ("diffusion_gemma", "DiffusionGemmaModel"),
        ("dinat", "DinatModel"),
        ("dinov2", "Dinov2Model"),
        ("dinov2_with_registers", "Dinov2WithRegistersModel"),
        ("dinov3_convnext", "DINOv3ConvNextModel"),
        ("dinov3_vit", "DINOv3ViTModel"),
        ("distilbert", "DistilBertModel"),
        ("doge", "DogeModel"),
        ("donut-swin", "DonutSwinModel"),
        ("dots1", "Dots1Model"),
        ("dpr", "DPRQuestionEncoder"),
        ("dpt", "DPTModel"),
        ("edgetam", "EdgeTamModel"),
        ("edgetam_video", "EdgeTamVideoModel"),
        ("edgetam_vision_model", "EdgeTamVisionModel"),
        ("efficientloftr", "EfficientLoFTRModel"),
        ("efficientnet", "EfficientNetModel"),
        ("electra", "ElectraModel"),
        ("embedding_gemma2", "EmbeddingGemma2Model"),
        ("embedding_gemma2_text", "EmbeddingGemma2TextModel"),
        ("emu3", "Emu3Model"),
        ("encodec", "EncodecModel"),
        ("ernie", "ErnieModel"),
        ("ernie4_5", "Ernie4_5Model"),
        ("ernie4_5_moe", "Ernie4_5_MoeModel"),
        ("ernie4_5_vl_moe", "Ernie4_5_VLMoeModel"),
        ("esm", "EsmModel"),
        ("esmc", "EsmcModel"),
        ("eurobert", "EuroBertModel"),
        ("evolla", "EvollaModel"),
        ("exaone4", "Exaone4Model"),
        ("exaone4_5", "Exaone4_5_Model"),
        ("exaone4_5_vision", "Exaone4_5_VisionModel"),
        ("exaone_moe", "ExaoneMoeModel"),
        ("falcon", "FalconModel"),
        ("falcon_h1", "FalconH1Model"),
        ("falcon_mamba", "FalconMambaModel"),
        ("fast_vlm", "FastVlmModel"),
        ("fastspeech2_conformer", "FastSpeech2ConformerModel"),
        ("fastspeech2_conformer_with_hifigan", "FastSpeech2ConformerWithHifiGan"),
        ("flaubert", "FlaubertModel"),
        ("flava", "FlavaModel"),
        ("flex_olmo", "FlexOlmoModel"),
        ("florence2", "Florence2Model"),
        ("fnet", "FNetModel"),
        ("focalnet", "FocalNetModel"),
        ("fsmt", "FSMTModel"),
        ("fun_asr_nano", "FunAsrNanoModel"),
        ("fun_asr_nano_encoder", "FunAsrNanoEncoder"),
        ("funnel", ("FunnelModel", "FunnelBaseModel")),
        ("fuyu", "FuyuModel"),
        ("gemma", "GemmaModel"),
        ("gemma2", "Gemma2Model"),
        ("gemma3", "Gemma3Model"),
        ("gemma3_text", "Gemma3TextModel"),
        ("gemma3n", "Gemma3nModel"),
        ("gemma3n_audio", "Gemma3nAudioEncoder"),
        ("gemma3n_text", "Gemma3nTextModel"),
        ("gemma3n_vision", "TimmWrapperModel"),
        ("gemma4", "Gemma4Model"),
        ("gemma4_audio", "Gemma4AudioModel"),
        ("gemma4_text", "Gemma4TextModel"),
        ("gemma4_unified", "Gemma4UnifiedModel"),
        ("gemma4_unified_text", "Gemma4UnifiedTextModel"),
        ("gemma4_vision", "Gemma4VisionModel"),
        ("git", "GitModel"),
        ("glm", "GlmModel"),
        ("glm4", "Glm4Model"),
        ("glm46v", "Glm46VModel"),
        ("glm4_moe", "Glm4MoeModel"),
        ("glm4_moe_lite", "Glm4MoeLiteModel"),
        ("glm4v", "Glm4vModel"),
        ("glm4v_moe", "Glm4vMoeModel"),
        ("glm4v_moe_text", "Glm4vMoeTextModel"),
        ("glm4v_moe_vision", "Glm4vMoeVisionModel"),
        ("glm4v_text", "Glm4vTextModel"),
        ("glm4v_vision", "Glm4vVisionModel"),
        ("glm5_next", "Glm5NextModel"),
        ("glm5_next_text", "Glm5NextTextModel"),
        ("glm5_next_vision", "Glm5NextVisionModel"),
        ("glm_image", "GlmImageModel"),
        ("glm_image_text", "GlmImageTextModel"),
        ("glm_image_vision", "GlmImageVisionModel"),
        ("glm_image_vqmodel", "GlmImageVQVAE"),
        ("glm_moe_dsa", "GlmMoeDsaModel"),
        ("glm_ocr", "GlmOcrModel"),
        ("glm_ocr_text", "GlmOcrTextModel"),
        ("glm_ocr_vision", "GlmOcrVisionModel"),
        ("glmasr", "GlmAsrModel"),
        ("glmasr_encoder", "GlmAsrEncoder"),
        ("glmga", "Glm46VModel"),
        ("glpn", "GLPNModel"),
        ("got_ocr2", "GotOcr2Model"),
        ("gpt-sw3", "GPT2Model"),
        ("gpt2", "GPT2Model"),
        ("gpt_bigcode", "GPTBigCodeModel"),
        ("gpt_neo", "GPTNeoModel"),
        ("gpt_neox", "GPTNeoXModel"),
        ("gpt_neox_japanese", "GPTNeoXJapaneseModel"),
        ("gpt_oss", "GptOssModel"),
        ("gptj", "GPTJModel"),
        ("granite", "GraniteModel"),
        ("granite4_vision", "Granite4VisionModel"),
        ("granite_speech", "GraniteSpeechModel"),
        ("granite_speech5_ctc", "GraniteSpeech5ForCTC"),
        ("granite_speech5_encoder", "GraniteSpeech5Encoder"),
        ("granite_speech_plus", "GraniteSpeechPlusModel"),
        ("granite_swa", "GraniteSWAModel"),
        ("granitemoe", "GraniteMoeModel"),
        ("granitemoe_swa", "GraniteMoeSWAModel"),
        ("granitemoehybrid", "GraniteMoeHybridModel"),
        ("granitemoeshared", "GraniteMoeSharedModel"),
        ("grounding-dino", "GroundingDinoModel"),
        ("groupvit", "GroupViTModel"),
        ("gte", "GteModel"),
        ("helium", "HeliumModel"),
        ("hgnet_v2", "HGNetV2Backbone"),
        ("hiera", "HieraModel"),
        ("higgs_audio_v2", "HiggsAudioV2ForConditionalGeneration"),
        ("higgs_audio_v2_tokenizer", "HiggsAudioV2TokenizerModel"),
        ("hrm_text", "HrmTextModel"),
        ("hubert", "HubertModel"),
        ("hunyuan_v1_dense", "HunYuanDenseV1Model"),
        ("hunyuan_v1_moe", "HunYuanMoEV1Model"),
        ("hunyuan_vl", "HunYuanVLModel"),
        ("hunyuan_vl_text", "HunYuanVLTextModel"),
        ("hunyuan_vl_vision", "HunYuanVLVisionTransformer"),
        ("hy_v3", "HYV3Model"),
        ("hy_v4", "HYV4Model"),
        ("hyperclovax", "HyperCLOVAXModel"),
        ("hyperclovax_vision_v2", "HyperCLOVAXVisionV2Model"),
        ("ibert", "IBertModel"),
        ("idefics", "IdeficsModel"),
        ("idefics2", "Idefics2Model"),
        ("idefics3", "Idefics3Model"),
        ("idefics3_vision", "Idefics3VisionTransformer"),
        ("ijepa", "IJepaModel"),
        ("imagegpt", "ImageGPTModel"),
        ("informer", "InformerModel"),
        ("inkling_mm_model", "InklingModel"),
        ("inkling_text", "InklingTextModel"),
        ("instructblip", "InstructBlipModel"),
        ("instructblipvideo", "InstructBlipVideoModel"),
        ("internvl", "InternVLModel"),
        ("internvl_vision", "InternVLVisionModel"),
        ("jais2", "Jais2Model"),
        ("jamba", "JambaModel"),
        ("janus", "JanusModel"),
        ("jetmoe", "JetMoeModel"),
        ("jina_embeddings_v3", "JinaEmbeddingsV3Model"),
        ("kimi_k25", "Kimi_K25Model"),
        ("kimi_k25_vision", "Kimi_K25VisionModel"),
        ("kimi_linear", "KimiLinearModel"),
        ("kolibri1", "Kolibri1Model"),
        ("kosmos-2", "Kosmos2Model"),
        ("kosmos-2.5", "Kosmos2_5Model"),
        ("kyutai_speech_to_text", "KyutaiSpeechToTextModel"),
        ("laguna", "LagunaModel"),
        ("lasr_ctc", "LasrForCTC"),
        ("lasr_encoder", "LasrEncoder"),
        ("layoutlm", "LayoutLMModel"),
        ("layoutlmv2", "LayoutLMv2Model"),
        ("layoutlmv3", "LayoutLMv3Model"),
        ("led", "LEDModel"),
        ("levit", "LevitModel"),
        ("lfm2", "Lfm2Model"),
        ("lfm2_moe", "Lfm2MoeModel"),
        ("lfm2_vl", "Lfm2VlModel"),
        ("lightglue", "LightGlueForKeypointMatching"),
        ("lighton_ocr", "LightOnOcrModel"),
        ("lilt", "LiltModel"),
        ("llama", "LlamaModel"),
        ("llama4", "Llama4ForConditionalGeneration"),
        ("llama4_text", "Llama4TextModel"),
        ("llava", "LlavaModel"),
        ("llava_next", "LlavaNextModel"),
        ("llava_next_video", "LlavaNextVideoModel"),
        ("llava_onevision", "LlavaOnevisionModel"),
        ("longcat_flash", "LongcatFlashModel"),
        ("longformer", "LongformerModel"),
        ("longt5", "LongT5Model"),
        ("luke", "LukeModel"),
        ("lw_detr", "LwDetrModel"),
        ("lxmert", "LxmertModel"),
        ("m2m_100", "M2M100Model"),
        ("mamba", "MambaModel"),
        ("mamba2", "Mamba2Model"),
        ("marian", "MarianModel"),
        ("markuplm", "MarkupLMModel"),
        ("mask2former", "Mask2FormerModel"),
        ("maskformer", "MaskFormerModel"),
        ("maskformer-swin", "MaskFormerSwinModel"),
        ("mbart", "MBartModel"),
        ("megatron-bert", "MegatronBertModel"),
        ("mellum", "MellumModel"),
        ("metaclip_2", "MetaClip2Model"),
        ("mgp-str", "MgpstrForSceneTextRecognition"),
        ("mimi", "MimiModel"),
        ("mimo_v2_flash", "MiMoV2FlashModel"),
        ("minicpm3", "MiniCPM3Model"),
        ("minicpmv4_6", "MiniCPMV4_6Model"),
        ("minicpmv4_7", "MiniCPMV4_7Model"),
        ("minicpmv4_7_vision", "MiniCPMV4_7VisionModel"),
        ("minimax", "MiniMaxModel"),
        ("minimax_m2", "MiniMaxM2Model"),
        ("minimax_m3_vl", "MiniMaxM3VLModel"),
        ("minimax_m3_vl_text", "MiniMaxM3VLTextModel"),
        ("ministral", "MinistralModel"),
        ("ministral3", "Ministral3Model"),
        ("mistral", "MistralModel"),
        ("mistral3", "Mistral3Model"),
        ("mistral4", "Mistral4Model"),
        ("mixtral", "MixtralModel"),
        ("mlcd", "MLCDVisionModel"),  # Keep this to make some original hub repositories (from `DeepGlint-AI`) works
        ("mlcd_vision_model", "MLCDVisionModel"),
        ("mllama", "MllamaModel"),
        ("mm-grounding-dino", "MMGroundingDinoModel"),
        ("mobilebert", "MobileBertModel"),
        ("mobilenet_v1", "MobileNetV1Model"),
        ("mobilenet_v2", "MobileNetV2Model"),
        ("mobilevit", "MobileViTModel"),
        ("mobilevitv2", "MobileViTV2Model"),
        ("modernbert", "ModernBertModel"),
        ("modernbert-decoder", "ModernBertDecoderModel"),
        ("modernvbert", "ModernVBertModel"),
        ("molmo2", "Molmo2Model"),
        ("molmo2_text", "Molmo2TextModel"),
        ("moonshine", "MoonshineModel"),
        ("moonshine_streaming", "MoonshineStreamingModel"),
        ("moshi", "MoshiModel"),
        ("moss_transcribe_diarize", "MossTranscribeDiarizeModel"),
        ("moss_transcribe_diarize_audio", "MossTranscribeDiarizeAudioModel"),
        ("mpnet", "MPNetModel"),
        ("mpt", "MptModel"),
        ("mra", "MraModel"),
        ("mt5", "MT5Model"),
        ("muse_glimmer", "MuseGlimmerModel"),
        ("muse_glimmer_assistant", "MuseGlimmerAssistantModel"),
        ("muse_glimmer_text", "MuseGlimmerTextModel"),
        ("muse_glimmer_vision", "MuseGlimmerVisionModel"),
        ("muse_spark", "MuseSparkModel"),
        ("muse_spark_audio", "MuseSparkAudioModel"),
        ("muse_spark_text", "MuseSparkTextModel"),
        ("muse_spark_vision", "MuseSparkVisionModel"),
        ("musicflamingo", "MusicFlamingoModel"),
        ("musicgen", "MusicgenModel"),
        ("musicgen_melody", "MusicgenMelodyModel"),
        ("mvp", "MvpModel"),
        ("nanochat", "NanoChatModel"),
        ("nemotron", "NemotronModel"),
        ("nemotron3_5_asr", "Nemotron3_5AsrForRNNT"),
        ("nemotron3_diarization", "Nemotron3DiarizationModel"),
        ("nemotron3_diarization_audio", "Nemotron3DiarizationAudioModel"),
        ("nemotron_asr_streaming", "NemotronAsrStreamingForRNNT"),
        ("nemotron_asr_streaming_encoder", "NemotronAsrStreamingEncoder"),
        ("nemotron_h", "NemotronHModel"),
        ("neomme", "NeoMMEModel"),
        ("neucodec", "NeuCodecModel"),
        ("nllb-moe", "NllbMoeModel"),
        ("nomic_bert", "NomicBertModel"),
        ("nystromformer", "NystromformerModel"),
        ("olmo", "OlmoModel"),
        ("olmo2", "Olmo2Model"),
        ("olmo3", "Olmo3Model"),
        ("olmo_hybrid", "OlmoHybridModel"),
        ("olmoe", "OlmoeModel"),
        ("omdet-turbo", "OmDetTurboForObjectDetection"),
        ("oneformer", "OneFormerModel"),
        ("openai-gpt", "OpenAIGPTModel"),
        ("openai_privacy_filter", "OpenAIPrivacyFilterModel"),
        ("opt", "OPTModel"),
        ("ovis2", "Ovis2Model"),
        ("owlv2", "Owlv2Model"),
        ("owlvit", "OwlViTModel"),
        ("paddleocr_vl", "PaddleOCRVLModel"),
        ("paligemma", "PaliGemmaModel"),
        ("parakeet_ctc", "ParakeetForCTC"),
        ("parakeet_encoder", "ParakeetEncoder"),
        ("parakeet_rnnt", "ParakeetForRNNT"),
        ("parakeet_tdt", "ParakeetForTDT"),
        ("patchtsmixer", "PatchTSMixerModel"),
        ("patchtst", "PatchTSTModel"),
        ("pe_audio", "PeAudioModel"),
        ("pe_audio_encoder", "PeAudioEncoder"),
        ("pe_audio_video", "PeAudioVideoModel"),
        ("pe_audio_video_encoder", "PeAudioVideoEncoder"),
        ("pe_video", "PeVideoModel"),
        ("pe_video_encoder", "PeVideoEncoder"),
        ("pegasus", "PegasusModel"),
        ("pegasus_x", "PegasusXModel"),
        ("perceiver", "PerceiverModel"),
        ("perception_lm", "PerceptionLMModel"),
        ("persimmon", "PersimmonModel"),
        ("phi", "PhiModel"),
        ("phi3", "Phi3Model"),
        ("phi4_multimodal", "Phi4MultimodalModel"),
        ("phimoe", "PhimoeModel"),
        ("pi0", "PI0Model"),
        ("pixio", "PixioModel"),
        ("pixtral", "PixtralVisionModel"),
        ("plbart", "PLBartModel"),
        ("poolformer", "PoolFormerModel"),
        ("pp_doclayout_v3", "PPDocLayoutV3Model"),
        ("pp_doclayout_v4", "PPDocLayoutV4Model"),
        ("pp_ocrv5_mobile_rec", "PPOCRV5MobileRecModel"),
        ("pp_ocrv5_server_rec", "PPOCRV5ServerRecModel"),
        ("pp_ocrv6_medium_det", "PPOCRV6MediumDetModel"),
        ("pp_ocrv6_small_det", "PPOCRV6SmallDetModel"),
        ("pp_ocrv6_small_rec", "PPOCRV6SmallRecModel"),
        ("pp_ocrv6_tiny_rec", "PPOCRV6TinyRecModel"),
        ("prophetnet", "ProphetNetModel"),
        ("pvt", "PvtModel"),
        ("pvt_v2", "PvtV2Model"),
        ("qianfan_ocr", "QianfanOCRModel"),
        ("qianfan_ocr_vision", "QianfanOCRVisionModel"),
        ("qwen2", "Qwen2Model"),
        ("qwen2_5_vl", "Qwen2_5_VLModel"),
        ("qwen2_5_vl_text", "Qwen2_5_VLTextModel"),
        ("qwen2_5_vl_vision", "Qwen2_5_VisionTransformerPretrainedModel"),
        ("qwen2_audio", "Qwen2AudioModel"),
        ("qwen2_audio_encoder", "Qwen2AudioEncoder"),
        ("qwen2_moe", "Qwen2MoeModel"),
        ("qwen2_vl", "Qwen2VLModel"),
        ("qwen2_vl_text", "Qwen2VLTextModel"),
        ("qwen3", "Qwen3Model"),
        ("qwen3_5", "Qwen3_5Model"),
        ("qwen3_5_moe", "Qwen3_5MoeModel"),
        ("qwen3_5_moe_text", "Qwen3_5MoeTextModel"),
        ("qwen3_5_moe_vision", "Qwen3_5MoeVisionModel"),
        ("qwen3_5_text", "Qwen3_5TextModel"),
        ("qwen3_5_vision", "Qwen3_5VisionModel"),
        ("qwen3_asr", "Qwen3ASRModel"),
        ("qwen3_asr_encoder", "Qwen3ASREncoder"),
        ("qwen3_moe", "Qwen3MoeModel"),
        ("qwen3_next", "Qwen3NextModel"),
        ("qwen3_vl", "Qwen3VLModel"),
        ("qwen3_vl_moe", "Qwen3VLMoeModel"),
        ("qwen3_vl_moe_text", "Qwen3VLMoeTextModel"),
        ("qwen3_vl_moe_vision", "Qwen3VLMoeVisionModel"),
        ("qwen3_vl_text", "Qwen3VLTextModel"),
        ("qwen3_vl_vision", "Qwen3VLVisionModel"),
        ("qwen4_exp", "Qwen4ExpModel"),
        ("qwen4_exp_text", "Qwen4ExpTextModel"),
        ("qwen4_exp_vision", "Qwen4ExpVisionModel"),
        ("radio", "RadioModel"),
        ("recurrent_gemma", "RecurrentGemmaModel"),
        ("reformer", "ReformerModel"),
        ("regnet", "RegNetModel"),
        ("rembert", "RemBertModel"),
        ("resnet", "ResNetModel"),
        ("rf_detr", "RfDetrModel"),
        ("roberta", "RobertaModel"),
        ("roberta-prelayernorm", "RobertaPreLayerNormModel"),
        ("roc_bert", "RoCBertModel"),
        ("roformer", "RoFormerModel"),
        ("rt_detr", "RTDetrModel"),
        ("rt_detr_v2", "RTDetrV2Model"),
        ("rwkv", "RwkvModel"),
        ("sam", "SamModel"),
        ("sam2", "Sam2Model"),
        ("sam2_hiera_det_model", "Sam2HieraDetModel"),
        ("sam2_video", "Sam2VideoModel"),
        ("sam2_vision_model", "Sam2VisionModel"),
        ("sam3", "Sam3Model"),
        ("sam3_lite_text", "Sam3LiteTextModel"),
        ("sam3_lite_text_text_model", "Sam3LiteTextTextModel"),
        ("sam3_tracker", "Sam3TrackerModel"),
        ("sam3_tracker", "Sam3TrackerModel"),
        ("sam3_tracker_video", "Sam3TrackerVideoModel"),
        ("sam3_video", "Sam3VideoModel"),
        ("sam3_vision_model", "Sam3VisionModel"),
        ("sam3_vit_model", "Sam3ViTModel"),
        ("sam_hq", "SamHQModel"),
        ("sam_hq_vision_model", "SamHQVisionModel"),
        ("sam_vision_model", "SamVisionModel"),
        ("sapiens2", "Sapiens2Model"),
        ("seamless_m4t", "SeamlessM4TModel"),
        ("seamless_m4t_v2", "SeamlessM4Tv2Model"),
        ("seed_oss", "SeedOssModel"),
        ("segformer", "SegformerModel"),
        ("seggpt", "SegGptModel"),
        ("sew", "SEWModel"),
        ("sew-d", "SEWDModel"),
        ("siglip", "SiglipModel"),
        ("siglip2", "Siglip2Model"),
        ("siglip2_vision_model", "Siglip2VisionModel"),
        ("siglip_vision_model", "SiglipVisionModel"),
        ("smollm3", "SmolLM3Model"),
        ("smolvlm", "SmolVLMModel"),
        ("smolvlm_vision", "SmolVLMVisionTransformer"),
        ("solar_open", "SolarOpenModel"),
        ("speech_to_text", "Speech2TextModel"),
        ("speecht5", "SpeechT5Model"),
        ("splinter", "SplinterModel"),
        ("squeezebert", "SqueezeBertModel"),
        ("stablelm", "StableLmModel"),
        ("starcoder2", "Starcoder2Model"),
        ("step3p7", "Step3p7Model"),
        ("swiftformer", "SwiftFormerModel"),
        ("swin", "SwinModel"),
        ("swin2sr", "Swin2SRModel"),
        ("swinv2", "Swinv2Model"),
        ("switch_transformers", "SwitchTransformersModel"),
        ("t5", "T5Model"),
        ("t5gemma", "T5GemmaModel"),
        ("t5gemma2", "T5Gemma2Model"),
        ("t5gemma2_encoder", "T5Gemma2Encoder"),
        ("table-transformer", "TableTransformerModel"),
        ("tapas", "TapasModel"),
        ("textnet", "TextNetModel"),
        ("time_series_transformer", "TimeSeriesTransformerModel"),
        ("timesfm", "TimesFmModel"),
        ("timesfm2_5", "TimesFm2_5Model"),
        ("timesformer", "TimesformerModel"),
        ("timm_backbone", "TimmBackbone"),
        ("timm_wrapper", "TimmWrapperModel"),
        ("tipsv2", "Tipsv2Model"),
        ("tipsv2_text_model", "Tipsv2TextModel"),
        ("tipsv2_vision_model", "Tipsv2VisionModel"),
        ("tvp", "TvpModel"),
        ("udop", "UdopModel"),
        ("ultrabert", "UltrabertModel"),
        ("umt5", "UMT5Model"),
        ("unispeech", "UniSpeechModel"),
        ("unispeech-sat", "UniSpeechSatModel"),
        ("univnet", "UnivNetModel"),
        ("unlimited_ocr", "UnlimitedOcrModel"),
        ("uvdoc", "UVDocModel"),
        ("vaultgemma", "VaultGemmaModel"),
        ("vibevoice", "VibeVoiceForConditionalGeneration"),
        ("vibevoice_acoustic_tokenizer", "VibeVoiceAcousticTokenizerModel"),
        ("vibevoice_acoustic_tokenizer_decoder", "VibeVoiceAcousticTokenizerDecoderModel"),
        ("vibevoice_acoustic_tokenizer_encoder", "VibeVoiceAcousticTokenizerEncoderModel"),
        ("vibevoice_asr", "VibeVoiceAsrModel"),
        ("video_llama_3", "VideoLlama3Model"),
        ("video_llama_3_vision", "VideoLlama3VisionModel"),
        ("video_llava", "VideoLlavaModel"),
        ("videomae", "VideoMAEModel"),
        ("videoprism", "VideoPrismClipModel"),
        ("videoprism_vision_model", "VideoPrismVisionModel"),
        ("vilt", "ViltModel"),
        ("vipllava", "VipLlavaModel"),
        ("vision-text-dual-encoder", "VisionTextDualEncoderModel"),
        ("visual_bert", "VisualBertModel"),
        ("vit", "ViTModel"),
        ("vit_mae", "ViTMAEModel"),
        ("vit_msn", "ViTMSNModel"),
        ("vitdet", "VitDetModel"),
        ("vits", "VitsModel"),
        ("vivit", "VivitModel"),
        ("vjepa2", "VJEPA2Model"),
        ("voxtral", "VoxtralModel"),
        ("voxtral_encoder", "VoxtralEncoder"),
        ("voxtral_realtime", "VoxtralRealtimeModel"),
        ("voxtral_realtime_encoder", "VoxtralRealtimeEncoder"),
        ("voxtral_realtime_text", "VoxtralRealtimeTextModel"),
        ("wav2vec2", "Wav2Vec2Model"),
        ("wav2vec2-bert", "Wav2Vec2BertModel"),
        ("wav2vec2-conformer", "Wav2Vec2ConformerModel"),
        ("wavlm", "WavLMModel"),
        ("whisper", "WhisperModel"),
        ("xclip", "XCLIPModel"),
        ("xcodec", "XcodecModel"),
        ("xcodec2", "Xcodec2Model"),
        ("xglm", "XGLMModel"),
        ("xlm", "XLMModel"),
        ("xlm-roberta", "XLMRobertaModel"),
        ("xlm-roberta-xl", "XLMRobertaXLModel"),
        ("xlnet", "XLNetModel"),
        ("xlstm", "xLSTMModel"),
        ("xmod", "XmodModel"),
        ("yolos", "YolosModel"),
        ("yoso", "YosoModel"),
        ("youtu", "YoutuModel"),
        ("zamba", "ZambaModel"),
        ("zamba2", "Zamba2Model"),
        ("zaya", "ZayaModel"),
    ]
)

MODEL_FOR_PRETRAINING_MAPPING_NAMES = OrderedDict(
    [
        # Model for pre-training mapping
        ("albert", "AlbertForPreTraining"),
        ("audioflamingo3", "AudioFlamingo3ForConditionalGeneration"),
        ("bart", "BartForConditionalGeneration"),
        ("bert", "BertForPreTraining"),
        ("big_bird", "BigBirdForPreTraining"),
        ("bloom", "BloomForCausalLM"),
        ("camembert", "CamembertForMaskedLM"),
        ("colmodernvbert", "ColModernVBertForRetrieval"),
        ("colpali", "ColPaliForRetrieval"),
        ("colqwen2", "ColQwen2ForRetrieval"),
        ("ctrl", "CTRLLMHeadModel"),
        ("data2vec-text", "Data2VecTextForMaskedLM"),
        ("deberta", "DebertaForMaskedLM"),
        ("deberta-v2", "DebertaV2ForMaskedLM"),
        ("distilbert", "DistilBertForMaskedLM"),
        ("electra", "ElectraForPreTraining"),
        ("ernie", "ErnieForPreTraining"),
        ("evolla", "EvollaForProteinText2Text"),
        ("exaone4", "Exaone4ForCausalLM"),
        ("exaone_moe", "ExaoneMoeForCausalLM"),
        ("falcon_mamba", "FalconMambaForCausalLM"),
        ("flaubert", "FlaubertWithLMHeadModel"),
        ("flava", "FlavaForPreTraining"),
        ("florence2", "Florence2ForConditionalGeneration"),
        ("fnet", "FNetForPreTraining"),
        ("fsmt", "FSMTForConditionalGeneration"),
        ("fun_asr_nano", "FunAsrNanoForConditionalGeneration"),
        ("funnel", "FunnelForPreTraining"),
        ("gemma3", "Gemma3ForConditionalGeneration"),
        ("gemma4", "Gemma4ForConditionalGeneration"),
        ("gemma4_unified", "Gemma4UnifiedForConditionalGeneration"),
        ("glmasr", "GlmAsrForConditionalGeneration"),
        ("gpt-sw3", "GPT2LMHeadModel"),
        ("gpt2", "GPT2LMHeadModel"),
        ("gpt_bigcode", "GPTBigCodeForCausalLM"),
        ("hiera", "HieraForPreTraining"),
        ("ibert", "IBertForMaskedLM"),
        ("idefics", "IdeficsForVisionText2Text"),
        ("idefics2", "Idefics2ForConditionalGeneration"),
        ("idefics3", "Idefics3ForConditionalGeneration"),
        ("inkling_mm_model", "InklingForConditionalGeneration"),
        ("janus", "JanusForConditionalGeneration"),
        ("layoutlm", "LayoutLMForMaskedLM"),
        ("llava", "LlavaForConditionalGeneration"),
        ("llava_next", "LlavaNextForConditionalGeneration"),
        ("llava_next_video", "LlavaNextVideoForConditionalGeneration"),
        ("llava_onevision", "LlavaOnevisionForConditionalGeneration"),
        ("longformer", "LongformerForMaskedLM"),
        ("luke", "LukeForMaskedLM"),
        ("lxmert", "LxmertForPreTraining"),
        ("mamba", "MambaForCausalLM"),
        ("mamba2", "Mamba2ForCausalLM"),
        ("megatron-bert", "MegatronBertForPreTraining"),
        ("mistral3", "Mistral3ForConditionalGeneration"),
        ("mistral4", "Mistral4ForCausalLM"),
        ("mllama", "MllamaForConditionalGeneration"),
        ("mobilebert", "MobileBertForPreTraining"),
        ("moss_transcribe_diarize", "MossTranscribeDiarizeForConditionalGeneration"),
        ("mpnet", "MPNetForMaskedLM"),
        ("mpt", "MptForCausalLM"),
        ("mra", "MraForMaskedLM"),
        ("musicflamingo", "MusicFlamingoForConditionalGeneration"),
        ("mvp", "MvpForConditionalGeneration"),
        ("nanochat", "NanoChatForCausalLM"),
        ("nllb-moe", "NllbMoeForConditionalGeneration"),
        ("openai-gpt", "OpenAIGPTLMHeadModel"),
        ("paligemma", "PaliGemmaForConditionalGeneration"),
        ("qwen2_audio", "Qwen2AudioForConditionalGeneration"),
        ("qwen3_asr", "Qwen3ASRForConditionalGeneration"),
        ("roberta", "RobertaForMaskedLM"),
        ("roberta-prelayernorm", "RobertaPreLayerNormForMaskedLM"),
        ("roc_bert", "RoCBertForPreTraining"),
        ("rwkv", "RwkvForCausalLM"),
        ("splinter", "SplinterForPreTraining"),
        ("squeezebert", "SqueezeBertForMaskedLM"),
        ("switch_transformers", "SwitchTransformersForConditionalGeneration"),
        ("t5", "T5ForConditionalGeneration"),
        ("t5gemma", "T5GemmaForConditionalGeneration"),
        ("t5gemma2", "T5Gemma2ForConditionalGeneration"),
        ("tapas", "TapasForMaskedLM"),
        ("unispeech", "UniSpeechForPreTraining"),
        ("unispeech-sat", "UniSpeechSatForPreTraining"),
        ("vibevoice_asr", "VibeVoiceAsrForConditionalGeneration"),
        ("video_llava", "VideoLlavaForConditionalGeneration"),
        ("videomae", "VideoMAEForPreTraining"),
        ("vipllava", "VipLlavaForConditionalGeneration"),
        ("visual_bert", "VisualBertForPreTraining"),
        ("vit_mae", "ViTMAEForPreTraining"),
        ("voxtral", "VoxtralForConditionalGeneration"),
        ("voxtral_realtime", "VoxtralRealtimeForConditionalGeneration"),
        ("wav2vec2", "Wav2Vec2ForPreTraining"),
        ("wav2vec2-conformer", "Wav2Vec2ConformerForPreTraining"),
        ("xlm", "XLMWithLMHeadModel"),
        ("xlm-roberta", "XLMRobertaForMaskedLM"),
        ("xlm-roberta-xl", "XLMRobertaXLForMaskedLM"),
        ("xlnet", "XLNetLMHeadModel"),
        ("xlstm", "xLSTMForCausalLM"),
        ("xmod", "XmodForMaskedLM"),
    ]
)

MODEL_FOR_CAUSAL_LM_MAPPING_NAMES = OrderedDict(
    [
        # Model for Causal LM mapping
        ("afmoe", "AfmoeForCausalLM"),
        ("apertus", "ApertusForCausalLM"),
        ("arcee", "ArceeForCausalLM"),
        ("aria_text", "AriaTextForCausalLM"),
        ("axk1", "AXK1ForCausalLM"),
        ("axk2", "AXK2ForCausalLM"),
        ("bailing_hybrid", "BailingHybridForCausalLM"),
        ("bamba", "BambaForCausalLM"),
        ("bart", "BartForCausalLM"),
        ("beam", "BeamForCausalLM"),
        ("bert", "BertLMHeadModel"),
        ("bert-generation", "BertGenerationDecoder"),
        ("big_bird", "BigBirdForCausalLM"),
        ("bigbird_pegasus", "BigBirdPegasusForCausalLM"),
        ("biogpt", "BioGptForCausalLM"),
        ("bitnet", "BitNetForCausalLM"),
        ("blenderbot", "BlenderbotForCausalLM"),
        ("blenderbot-small", "BlenderbotSmallForCausalLM"),
        ("bloom", "BloomForCausalLM"),
        ("blt", "BltForCausalLM"),
        ("camembert", "CamembertForCausalLM"),
        ("codegen", "CodeGenForCausalLM"),
        ("cohere", "CohereForCausalLM"),
        ("cohere2", "Cohere2ForCausalLM"),
        ("cohere2_moe", "Cohere2MoeForCausalLM"),
        ("cohere_compass_text", "CohereCompassForCausalLM"),
        ("cpmant", "CpmAntForCausalLM"),
        ("ctrl", "CTRLLMHeadModel"),
        ("cwm", "CwmForCausalLM"),
        ("data2vec-text", "Data2VecTextForCausalLM"),
        ("dbrx", "DbrxForCausalLM"),
        ("deepseek_v2", "DeepseekV2ForCausalLM"),
        ("deepseek_v3", "DeepseekV3ForCausalLM"),
        ("deepseek_v32", "DeepseekV32ForCausalLM"),
        ("deepseek_v4", "DeepseekV4ForCausalLM"),
        ("diffllama", "DiffLlamaForCausalLM"),
        ("doge", "DogeForCausalLM"),
        ("dots1", "Dots1ForCausalLM"),
        ("electra", "ElectraForCausalLM"),
        ("emu3", "Emu3ForCausalLM"),
        ("ernie", "ErnieForCausalLM"),
        ("ernie4_5", "Ernie4_5ForCausalLM"),
        ("ernie4_5_moe", "Ernie4_5_MoeForCausalLM"),
        ("exaone4", "Exaone4ForCausalLM"),
        ("exaone_moe", "ExaoneMoeForCausalLM"),
        ("falcon", "FalconForCausalLM"),
        ("falcon_h1", "FalconH1ForCausalLM"),
        ("falcon_mamba", "FalconMambaForCausalLM"),
        ("flex_olmo", "FlexOlmoForCausalLM"),
        ("fuyu", "FuyuForCausalLM"),
        ("gemma", "GemmaForCausalLM"),
        ("gemma2", "Gemma2ForCausalLM"),
        ("gemma3", "Gemma3ForConditionalGeneration"),
        ("gemma3_text", "Gemma3ForCausalLM"),
        ("gemma3n", "Gemma3nForConditionalGeneration"),
        ("gemma3n_text", "Gemma3nForCausalLM"),
        ("gemma4", "Gemma4ForConditionalGeneration"),
        ("gemma4_assistant", "Gemma4AssistantForCausalLM"),
        ("gemma4_text", "Gemma4ForCausalLM"),
        ("gemma4_unified", "Gemma4UnifiedForConditionalGeneration"),
        ("gemma4_unified_assistant", "Gemma4UnifiedAssistantForCausalLM"),
        ("gemma4_unified_text", "Gemma4UnifiedForCausalLM"),
        ("git", "GitForCausalLM"),
        ("glm", "GlmForCausalLM"),
        ("glm4", "Glm4ForCausalLM"),
        ("glm4_moe", "Glm4MoeForCausalLM"),
        ("glm4_moe_lite", "Glm4MoeLiteForCausalLM"),
        ("glm_moe_dsa", "GlmMoeDsaForCausalLM"),
        ("got_ocr2", "GotOcr2ForConditionalGeneration"),
        ("gpt-sw3", "GPT2LMHeadModel"),
        ("gpt2", "GPT2LMHeadModel"),
        ("gpt_bigcode", "GPTBigCodeForCausalLM"),
        ("gpt_neo", "GPTNeoForCausalLM"),
        ("gpt_neox", "GPTNeoXForCausalLM"),
        ("gpt_neox_japanese", "GPTNeoXJapaneseForCausalLM"),
        ("gpt_oss", "GptOssForCausalLM"),
        ("gptj", "GPTJForCausalLM"),
        ("granite", "GraniteForCausalLM"),
        ("granite_swa", "GraniteSWAForCausalLM"),
        ("granitemoe", "GraniteMoeForCausalLM"),
        ("granitemoe_swa", "GraniteMoeSWAForCausalLM"),
        ("granitemoehybrid", "GraniteMoeHybridForCausalLM"),
        ("granitemoeshared", "GraniteMoeSharedForCausalLM"),
        ("helium", "HeliumForCausalLM"),
        ("hrm_text", "HrmTextForCausalLM"),
        ("hunyuan_v1_dense", "HunYuanDenseV1ForCausalLM"),
        ("hunyuan_v1_moe", "HunYuanMoEV1ForCausalLM"),
        ("hy_v3", "HYV3ForCausalLM"),
        ("hy_v4", "HYV4ForCausalLM"),
        ("hyperclovax", "HyperCLOVAXForCausalLM"),
        ("inkling_text", "InklingForCausalLM"),
        ("jais2", "Jais2ForCausalLM"),
        ("jamba", "JambaForCausalLM"),
        ("jetmoe", "JetMoeForCausalLM"),
        ("kimi_linear", "KimiLinearForCausalLM"),
        ("kolibri1", "Kolibri1ForCausalLM"),
        ("laguna", "LagunaForCausalLM"),
        ("lfm2", "Lfm2ForCausalLM"),
        ("lfm2_moe", "Lfm2MoeForCausalLM"),
        ("llama", "LlamaForCausalLM"),
        ("llama4", "Llama4ForCausalLM"),
        ("llama4_text", "Llama4ForCausalLM"),
        ("longcat_flash", "LongcatFlashForCausalLM"),
        ("mamba", "MambaForCausalLM"),
        ("mamba2", "Mamba2ForCausalLM"),
        ("marian", "MarianForCausalLM"),
        ("mbart", "MBartForCausalLM"),
        ("megatron-bert", "MegatronBertForCausalLM"),
        ("mellum", "MellumForCausalLM"),
        ("mimo_v2_flash", "MiMoV2FlashForCausalLM"),
        ("minicpm3", "MiniCPM3ForCausalLM"),
        ("minimax", "MiniMaxForCausalLM"),
        ("minimax_m2", "MiniMaxM2ForCausalLM"),
        ("minimax_m3_vl_text", "MiniMaxM3VLForCausalLM"),
        ("ministral", "MinistralForCausalLM"),
        ("ministral3", "Ministral3ForCausalLM"),
        ("mistral", "MistralForCausalLM"),
        ("mixtral", "MixtralForCausalLM"),
        ("mllama", "MllamaForCausalLM"),
        ("modernbert-decoder", "ModernBertDecoderForCausalLM"),
        ("moshi", "MoshiForCausalLM"),
        ("moss_transcribe_diarize", "MossTranscribeDiarizeForConditionalGeneration"),
        ("mpt", "MptForCausalLM"),
        ("musicgen", "MusicgenForCausalLM"),
        ("musicgen_melody", "MusicgenMelodyForCausalLM"),
        ("mvp", "MvpForCausalLM"),
        ("nanochat", "NanoChatForCausalLM"),
        ("nemotron", "NemotronForCausalLM"),
        ("nemotron_h", "NemotronHForCausalLM"),
        ("olmo", "OlmoForCausalLM"),
        ("olmo2", "Olmo2ForCausalLM"),
        ("olmo3", "Olmo3ForCausalLM"),
        ("olmo_hybrid", "OlmoHybridForCausalLM"),
        ("olmoe", "OlmoeForCausalLM"),
        ("openai-gpt", "OpenAIGPTLMHeadModel"),
        ("opt", "OPTForCausalLM"),
        ("pegasus", "PegasusForCausalLM"),
        ("persimmon", "PersimmonForCausalLM"),
        ("phi", "PhiForCausalLM"),
        ("phi3", "Phi3ForCausalLM"),
        ("phi4_multimodal", "Phi4MultimodalForCausalLM"),
        ("phimoe", "PhimoeForCausalLM"),
        ("plbart", "PLBartForCausalLM"),
        ("prophetnet", "ProphetNetForCausalLM"),
        ("qwen2", "Qwen2ForCausalLM"),
        ("qwen2_moe", "Qwen2MoeForCausalLM"),
        ("qwen3", "Qwen3ForCausalLM"),
        ("qwen3_5", "Qwen3_5ForCausalLM"),  # VLM compatibility
        ("qwen3_5_moe", "Qwen3_5MoeForCausalLM"),  # VLM compatibility
        ("qwen3_5_moe_text", "Qwen3_5MoeForCausalLM"),
        ("qwen3_5_text", "Qwen3_5ForCausalLM"),
        ("qwen3_moe", "Qwen3MoeForCausalLM"),
        ("qwen3_next", "Qwen3NextForCausalLM"),
        ("qwen4_exp", "Qwen4ExpForCausalLM"),  # VLM compatibility
        ("qwen4_exp_text", "Qwen4ExpForCausalLM"),
        ("recurrent_gemma", "RecurrentGemmaForCausalLM"),
        ("reformer", "ReformerModelWithLMHead"),
        ("rembert", "RemBertForCausalLM"),
        ("roberta", "RobertaForCausalLM"),
        ("roberta-prelayernorm", "RobertaPreLayerNormForCausalLM"),
        ("roc_bert", "RoCBertForCausalLM"),
        ("roformer", "RoFormerForCausalLM"),
        ("rwkv", "RwkvForCausalLM"),
        ("seed_oss", "SeedOssForCausalLM"),
        ("smollm3", "SmolLM3ForCausalLM"),
        ("solar_open", "SolarOpenForCausalLM"),
        ("stablelm", "StableLmForCausalLM"),
        ("starcoder2", "Starcoder2ForCausalLM"),
        ("trocr", "TrOCRForCausalLM"),
        ("vaultgemma", "VaultGemmaForCausalLM"),
        ("whisper", "WhisperForCausalLM"),
        ("xglm", "XGLMForCausalLM"),
        ("xlm", "XLMWithLMHeadModel"),
        ("xlm-roberta", "XLMRobertaForCausalLM"),
        ("xlm-roberta-xl", "XLMRobertaXLForCausalLM"),
        ("xlnet", "XLNetLMHeadModel"),
        ("xlstm", "xLSTMForCausalLM"),
        ("xmod", "XmodForCausalLM"),
        ("youtu", "YoutuForCausalLM"),
        ("zamba", "ZambaForCausalLM"),
        ("zamba2", "Zamba2ForCausalLM"),
        ("zaya", "ZayaForCausalLM"),
    ]
)

MODEL_FOR_IMAGE_MAPPING_NAMES = OrderedDict(
    [
        # Model for Image mapping
        ("aimv2_vision_model", "Aimv2VisionModel"),
        ("beit", "BeitModel"),
        ("bit", "BitModel"),
        ("cohere2_vision", "Cohere2VisionModel"),
        ("conditional_detr", "ConditionalDetrModel"),
        ("convnext", "ConvNextModel"),
        ("convnextv2", "ConvNextV2Model"),
        ("dab-detr", "DabDetrModel"),
        ("data2vec-vision", "Data2VecVisionModel"),
        ("deformable_detr", "DeformableDetrModel"),
        ("deit", "DeiTModel"),
        ("depth_pro", "DepthProModel"),
        ("detr", "DetrModel"),
        ("dinat", "DinatModel"),
        ("dinov2", "Dinov2Model"),
        ("dinov2_with_registers", "Dinov2WithRegistersModel"),
        ("dinov3_convnext", "DINOv3ConvNextModel"),
        ("dinov3_vit", "DINOv3ViTModel"),
        ("dpt", "DPTModel"),
        ("efficientnet", "EfficientNetModel"),
        ("focalnet", "FocalNetModel"),
        ("glpn", "GLPNModel"),
        ("hiera", "HieraModel"),
        ("ijepa", "IJepaModel"),
        ("imagegpt", "ImageGPTModel"),
        ("levit", "LevitModel"),
        ("llama4", "Llama4VisionModel"),
        ("mlcd", "MLCDVisionModel"),  # Keep this to make some original hub repositories (from `DeepGlint-AI`) works
        ("mlcd_vision_model", "MLCDVisionModel"),
        ("mllama", "MllamaVisionModel"),
        ("mobilenet_v1", "MobileNetV1Model"),
        ("mobilenet_v2", "MobileNetV2Model"),
        ("mobilevit", "MobileViTModel"),
        ("mobilevitv2", "MobileViTV2Model"),
        ("pixio", "PixioModel"),
        ("poolformer", "PoolFormerModel"),
        ("pvt", "PvtModel"),
        ("regnet", "RegNetModel"),
        ("resnet", "ResNetModel"),
        ("segformer", "SegformerModel"),
        ("siglip_vision_model", "SiglipVisionModel"),
        ("swiftformer", "SwiftFormerModel"),
        ("swin", "SwinModel"),
        ("swin2sr", "Swin2SRModel"),
        ("swinv2", "Swinv2Model"),
        ("table-transformer", "TableTransformerModel"),
        ("timesformer", "TimesformerModel"),
        ("timm_backbone", "TimmBackbone"),
        ("timm_wrapper", "TimmWrapperModel"),
        ("tipsv2_vision_model", "Tipsv2VisionModel"),
        ("videomae", "VideoMAEModel"),
        ("videoprism_vision_model", "VideoPrismVisionModel"),
        ("vit", "ViTModel"),
        ("vit_mae", "ViTMAEModel"),
        ("vit_msn", "ViTMSNModel"),
        ("vitdet", "VitDetModel"),
        ("vivit", "VivitModel"),
        ("yolos", "YolosModel"),
    ]
)

MODEL_FOR_MASKED_IMAGE_MODELING_MAPPING_NAMES = OrderedDict(
    [
        ("deit", "DeiTForMaskedImageModeling"),
        ("focalnet", "FocalNetForMaskedImageModeling"),
        ("swin", "SwinForMaskedImageModeling"),
        ("swinv2", "Swinv2ForMaskedImageModeling"),
        ("vit", "ViTForMaskedImageModeling"),
    ]
)


MODEL_FOR_CAUSAL_IMAGE_MODELING_MAPPING_NAMES = OrderedDict(
    # Model for Causal Image Modeling mapping
    [
        ("imagegpt", "ImageGPTForCausalImageModeling"),
    ]
)

MODEL_FOR_IMAGE_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Image Classification mapping
        ("beit", "BeitForImageClassification"),
        ("bit", "BitForImageClassification"),
        ("clip", "CLIPForImageClassification"),
        ("convnext", "ConvNextForImageClassification"),
        ("convnextv2", "ConvNextV2ForImageClassification"),
        ("cvt", "CvtForImageClassification"),
        ("data2vec-vision", "Data2VecVisionForImageClassification"),
        (
            "deit",
            ("DeiTForImageClassification", "DeiTForImageClassificationWithTeacher"),
        ),
        ("dinat", "DinatForImageClassification"),
        ("dinov2", "Dinov2ForImageClassification"),
        ("dinov2_with_registers", "Dinov2WithRegistersForImageClassification"),
        ("donut-swin", "DonutSwinForImageClassification"),
        ("efficientnet", "EfficientNetForImageClassification"),
        ("focalnet", "FocalNetForImageClassification"),
        ("hgnet_v2", "HGNetV2ForImageClassification"),
        ("hiera", "HieraForImageClassification"),
        ("ijepa", "IJepaForImageClassification"),
        ("imagegpt", "ImageGPTForImageClassification"),
        (
            "levit",
            ("LevitForImageClassification", "LevitForImageClassificationWithTeacher"),
        ),
        ("metaclip_2", "MetaClip2ForImageClassification"),
        ("mobilenet_v1", "MobileNetV1ForImageClassification"),
        ("mobilenet_v2", "MobileNetV2ForImageClassification"),
        ("mobilevit", "MobileViTForImageClassification"),
        ("mobilevitv2", "MobileViTV2ForImageClassification"),
        (
            "perceiver",
            (
                "PerceiverForImageClassificationLearned",
                "PerceiverForImageClassificationFourier",
                "PerceiverForImageClassificationConvProcessing",
            ),
        ),
        ("poolformer", "PoolFormerForImageClassification"),
        ("pp_lcnet", "PPLCNetForImageClassification"),
        ("pvt", "PvtForImageClassification"),
        ("pvt_v2", "PvtV2ForImageClassification"),
        ("regnet", "RegNetForImageClassification"),
        ("resnet", "ResNetForImageClassification"),
        ("segformer", "SegformerForImageClassification"),
        ("shieldgemma2", "ShieldGemma2ForImageClassification"),
        ("siglip", "SiglipForImageClassification"),
        ("siglip2", "Siglip2ForImageClassification"),
        ("swiftformer", "SwiftFormerForImageClassification"),
        ("swin", "SwinForImageClassification"),
        ("swinv2", "Swinv2ForImageClassification"),
        ("textnet", "TextNetForImageClassification"),
        ("timm_wrapper", "TimmWrapperForImageClassification"),
        ("vit", "ViTForImageClassification"),
        ("vit_msn", "ViTMSNForImageClassification"),
    ]
)

MODEL_FOR_IMAGE_SEGMENTATION_MAPPING_NAMES = OrderedDict(
    [
        # Do not add new models here, this class will be deprecated in the future.
        # Model for Image Segmentation mapping
        ("detr", "DetrForSegmentation"),
    ]
)

MODEL_FOR_SEMANTIC_SEGMENTATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Semantic Segmentation mapping
        ("beit", "BeitForSemanticSegmentation"),
        ("data2vec-vision", "Data2VecVisionForSemanticSegmentation"),
        ("dpt", "DPTForSemanticSegmentation"),
        ("mobilenet_v2", "MobileNetV2ForSemanticSegmentation"),
        ("mobilevit", "MobileViTForSemanticSegmentation"),
        ("mobilevitv2", "MobileViTV2ForSemanticSegmentation"),
        ("sapiens2", "Sapiens2ForSemanticSegmentation"),
        ("segformer", "SegformerForSemanticSegmentation"),
        ("tipsv2_dpt", "Tipsv2DptForSemanticSegmentation"),
        ("upernet", "UperNetForSemanticSegmentation"),
    ]
)

MODEL_FOR_INSTANCE_SEGMENTATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Instance Segmentation mapping
        # MaskFormerForInstanceSegmentation can be removed from this mapping in v5
        ("maskformer", "MaskFormerForInstanceSegmentation"),
        ("rf_detr", "RfDetrForInstanceSegmentation"),
    ]
)

MODEL_FOR_UNIVERSAL_SEGMENTATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Universal Segmentation mapping
        ("detr", "DetrForSegmentation"),
        ("eomt", "EomtForUniversalSegmentation"),
        ("eomt_dinov3", "EomtDinov3ForUniversalSegmentation"),
        ("mask2former", "Mask2FormerForUniversalSegmentation"),
        ("maskformer", "MaskFormerForInstanceSegmentation"),
        ("oneformer", "OneFormerForUniversalSegmentation"),
        ("videomt", "VideomtForUniversalSegmentation"),
    ]
)

MODEL_FOR_VIDEO_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        ("timesformer", "TimesformerForVideoClassification"),
        ("videomae", "VideoMAEForVideoClassification"),
        ("videoprism_vision_model", "VideoPrismForVideoClassification"),
        ("vivit", "VivitForVideoClassification"),
        ("vjepa2", "VJEPA2ForVideoClassification"),
    ]
)

MODEL_FOR_RETRIEVAL_MAPPING_NAMES = OrderedDict(
    [
        ("colmodernvbert", "ColModernVBertForRetrieval"),
        ("colpali", "ColPaliForRetrieval"),
    ]
)

MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES = OrderedDict(
    [
        ("aria", "AriaForConditionalGeneration"),
        ("aya_vision", "AyaVisionForConditionalGeneration"),
        ("blip", "BlipForConditionalGeneration"),
        ("blip-2", "Blip2ForConditionalGeneration"),
        ("chameleon", "ChameleonForConditionalGeneration"),
        ("cohere2_vision", "Cohere2VisionForConditionalGeneration"),
        ("cohere_compass", "CohereCompassForConditionalGeneration"),
        ("cosmos3_edge", "Cosmos3EdgeForConditionalGeneration"),
        ("cosmos3_omni", "Cosmos3OmniForConditionalGeneration"),
        ("deepseek_ocr2", "DeepseekOcr2ForConditionalGeneration"),
        ("deepseek_vl", "DeepseekVLForConditionalGeneration"),
        ("deepseek_vl_hybrid", "DeepseekVLHybridForConditionalGeneration"),
        ("diffusion_gemma", "DiffusionGemmaForBlockDiffusion"),
        ("emu3", "Emu3ForConditionalGeneration"),
        ("ernie4_5_vl_moe", "Ernie4_5_VLMoeForConditionalGeneration"),
        ("evolla", "EvollaForProteinText2Text"),
        ("exaone4_5", "Exaone4_5_ForConditionalGeneration"),
        ("fast_vlm", "FastVlmForConditionalGeneration"),
        ("florence2", "Florence2ForConditionalGeneration"),
        ("fuyu", "FuyuForCausalLM"),
        ("gemma3", "Gemma3ForConditionalGeneration"),
        ("gemma3n", "Gemma3nForConditionalGeneration"),
        ("gemma4", "Gemma4ForConditionalGeneration"),
        ("gemma4_unified", "Gemma4UnifiedForConditionalGeneration"),
        ("git", "GitForCausalLM"),
        ("glm46v", "Glm46VForConditionalGeneration"),
        ("glm4v", "Glm4vForConditionalGeneration"),
        ("glm4v_moe", "Glm4vMoeForConditionalGeneration"),
        ("glm5_next", "Glm5NextForConditionalGeneration"),
        ("glm_ocr", "GlmOcrForConditionalGeneration"),
        ("glmga", "Glm46VForConditionalGeneration"),
        ("got_ocr2", "GotOcr2ForConditionalGeneration"),
        ("granite4_vision", "Granite4VisionForConditionalGeneration"),
        ("hunyuan_vl", "HunYuanVLForConditionalGeneration"),
        ("hyperclovax_vision_v2", "HyperCLOVAXVisionV2ForConditionalGeneration"),
        ("idefics", "IdeficsForVisionText2Text"),
        ("idefics2", "Idefics2ForConditionalGeneration"),
        ("idefics3", "Idefics3ForConditionalGeneration"),
        ("inkling_mm_model", "InklingForConditionalGeneration"),
        ("instructblip", "InstructBlipForConditionalGeneration"),
        ("instructblipvideo", "InstructBlipVideoForConditionalGeneration"),
        ("internvl", "InternVLForConditionalGeneration"),
        ("janus", "JanusForConditionalGeneration"),
        ("kimi_k25", "Kimi_K25ForConditionalGeneration"),
        ("kosmos-2", "Kosmos2ForConditionalGeneration"),
        ("kosmos-2.5", "Kosmos2_5ForConditionalGeneration"),
        ("lfm2_vl", "Lfm2VlForConditionalGeneration"),
        ("lighton_ocr", "LightOnOcrForConditionalGeneration"),
        ("llama4", "Llama4ForConditionalGeneration"),
        ("llava", "LlavaForConditionalGeneration"),
        ("llava_next", "LlavaNextForConditionalGeneration"),
        ("llava_next_video", "LlavaNextVideoForConditionalGeneration"),
        ("llava_onevision", "LlavaOnevisionForConditionalGeneration"),
        ("minicpmv4_6", "MiniCPMV4_6ForConditionalGeneration"),
        ("minicpmv4_7", "MiniCPMV4_7ForConditionalGeneration"),
        ("minimax_m3_vl", "MiniMaxM3SparseForConditionalGeneration"),
        ("mistral3", "Mistral3ForConditionalGeneration"),
        ("mistral4", "Mistral4ForCausalLM"),
        ("mllama", "MllamaForConditionalGeneration"),
        ("molmo2", "Molmo2ForConditionalGeneration"),
        ("muse_glimmer", "MuseGlimmerForConditionalGeneration"),
        ("muse_spark", "MuseSparkForConditionalGeneration"),
        ("nemotron_h_omni", "NemotronH_Omni_Reasoning_V3"),
        ("ovis2", "Ovis2ForConditionalGeneration"),
        ("paddleocr_vl", "PaddleOCRVLForConditionalGeneration"),
        ("paligemma", "PaliGemmaForConditionalGeneration"),
        ("perception_lm", "PerceptionLMForConditionalGeneration"),
        ("pi0", "PI0ForConditionalGeneration"),
        ("pix2struct", "Pix2StructForConditionalGeneration"),
        ("pp_chart2table", "GotOcr2ForConditionalGeneration"),
        ("pp_formulanet", "PPFormulaNetForConditionalGeneration"),
        ("qianfan_ocr", "QianfanOCRForConditionalGeneration"),
        ("qwen2_5_omni_thinker", "Qwen2_5OmniThinkerForConditionalGeneration"),
        ("qwen2_5_vl", "Qwen2_5_VLForConditionalGeneration"),
        ("qwen2_vl", "Qwen2VLForConditionalGeneration"),
        ("qwen3_5", "Qwen3_5ForConditionalGeneration"),
        ("qwen3_5_moe", "Qwen3_5MoeForConditionalGeneration"),
        ("qwen3_omni_moe_thinker", "Qwen3OmniMoeThinkerForConditionalGeneration"),
        ("qwen3_vl", "Qwen3VLForConditionalGeneration"),
        ("qwen3_vl_moe", "Qwen3VLMoeForConditionalGeneration"),
        ("qwen4_exp", "Qwen4ExpForConditionalGeneration"),
        ("shieldgemma2", "Gemma3ForConditionalGeneration"),
        ("smolvlm", "SmolVLMForConditionalGeneration"),
        ("step3p7", "Step3p7ForConditionalGeneration"),
        ("t5gemma2", "T5Gemma2ForConditionalGeneration"),
        ("udop", "UdopForConditionalGeneration"),
        ("unlimited_ocr", "UnlimitedOcrForConditionalGeneration"),
        ("video_llama_3", "VideoLlama3ForConditionalGeneration"),
        ("video_llava", "VideoLlavaForConditionalGeneration"),
        ("vipllava", "VipLlavaForConditionalGeneration"),
        ("vision-encoder-decoder", "VisionEncoderDecoderModel"),
    ]
)

# Models that accept text and optionally multimodal data in inputs
# and can generate text and optionally multimodal data.
MODEL_FOR_MULTIMODAL_LM_MAPPING_NAMES = OrderedDict(
    [
        *list(MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES.items()),
        ("fun_asr_nano", "FunAsrNanoForConditionalGeneration"),
        ("glmasr", "GlmAsrForConditionalGeneration"),
        ("granite_speech", "GraniteSpeechForConditionalGeneration"),
        ("granite_speech_plus", "GraniteSpeechPlusForConditionalGeneration"),
        ("kyutai_speech_to_text", "KyutaiSpeechToTextForConditionalGeneration"),
        ("moss_transcribe_diarize", "MossTranscribeDiarizeForConditionalGeneration"),
        ("phi4_multimodal", "Phi4MultimodalForCausalLM"),
        ("qwen2_5_omni", "Qwen2_5OmniForConditionalGeneration"),
        ("qwen2_audio", "Qwen2AudioForConditionalGeneration"),
        ("qwen3_asr", "Qwen3ASRForConditionalGeneration"),
        ("qwen3_omni_moe", "Qwen3OmniMoeForConditionalGeneration"),
        ("vibevoice_asr", "VibeVoiceAsrForConditionalGeneration"),
        ("voxtral", "VoxtralForConditionalGeneration"),
        ("voxtral_realtime", "VoxtralRealtimeForConditionalGeneration"),
    ]
)


MODEL_FOR_MASKED_LM_MAPPING_NAMES = OrderedDict(
    [
        # Model for Masked LM mapping
        ("albert", "AlbertForMaskedLM"),
        ("bart", "BartForConditionalGeneration"),
        ("bert", "BertForMaskedLM"),
        ("big_bird", "BigBirdForMaskedLM"),
        ("camembert", "CamembertForMaskedLM"),
        ("convbert", "ConvBertForMaskedLM"),
        ("data2vec-text", "Data2VecTextForMaskedLM"),
        ("deberta", "DebertaForMaskedLM"),
        ("deberta-v2", "DebertaV2ForMaskedLM"),
        ("distilbert", "DistilBertForMaskedLM"),
        ("electra", "ElectraForMaskedLM"),
        ("ernie", "ErnieForMaskedLM"),
        ("esm", "EsmForMaskedLM"),
        ("esmc", "EsmcForMaskedLM"),
        ("eurobert", "EuroBertForMaskedLM"),
        ("flaubert", "FlaubertWithLMHeadModel"),
        ("fnet", "FNetForMaskedLM"),
        ("funnel", "FunnelForMaskedLM"),
        ("gte", "GteForMaskedLM"),
        ("ibert", "IBertForMaskedLM"),
        ("jina_embeddings_v3", "JinaEmbeddingsV3ForMaskedLM"),
        ("layoutlm", "LayoutLMForMaskedLM"),
        ("longformer", "LongformerForMaskedLM"),
        ("luke", "LukeForMaskedLM"),
        ("mbart", "MBartForConditionalGeneration"),
        ("megatron-bert", "MegatronBertForMaskedLM"),
        ("mobilebert", "MobileBertForMaskedLM"),
        ("modernbert", "ModernBertForMaskedLM"),
        ("modernvbert", "ModernVBertForMaskedLM"),
        ("mpnet", "MPNetForMaskedLM"),
        ("mra", "MraForMaskedLM"),
        ("mvp", "MvpForConditionalGeneration"),
        ("neomme", "NeoMMEForMaskedLM"),
        ("nomic_bert", "NomicBertForMaskedLM"),
        ("nystromformer", "NystromformerForMaskedLM"),
        ("perceiver", "PerceiverForMaskedLM"),
        ("reformer", "ReformerForMaskedLM"),
        ("rembert", "RemBertForMaskedLM"),
        ("roberta", "RobertaForMaskedLM"),
        ("roberta-prelayernorm", "RobertaPreLayerNormForMaskedLM"),
        ("roc_bert", "RoCBertForMaskedLM"),
        ("roformer", "RoFormerForMaskedLM"),
        ("squeezebert", "SqueezeBertForMaskedLM"),
        ("tapas", "TapasForMaskedLM"),
        ("ultrabert", "UltrabertForMaskedLM"),
        ("xlm", "XLMWithLMHeadModel"),
        ("xlm-roberta", "XLMRobertaForMaskedLM"),
        ("xlm-roberta-xl", "XLMRobertaXLForMaskedLM"),
        ("xmod", "XmodForMaskedLM"),
        ("yoso", "YosoForMaskedLM"),
    ]
)

MODEL_FOR_OBJECT_DETECTION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Object Detection mapping
        ("conditional_detr", "ConditionalDetrForObjectDetection"),
        ("d_fine", "DFineForObjectDetection"),
        ("dab-detr", "DabDetrForObjectDetection"),
        ("deformable_detr", "DeformableDetrForObjectDetection"),
        ("deimv2", "Deimv2ForObjectDetection"),
        ("detr", "DetrForObjectDetection"),
        ("lw_detr", "LwDetrForObjectDetection"),
        ("pp_doclayout_v2", "PPDocLayoutV2ForObjectDetection"),
        ("pp_doclayout_v3", "PPDocLayoutV3ForObjectDetection"),
        ("pp_doclayout_v4", "PPDocLayoutV4ForObjectDetection"),
        ("pp_ocrv5_mobile_det", "PPOCRV5MobileDetForObjectDetection"),
        ("pp_ocrv5_server_det", "PPOCRV5ServerDetForObjectDetection"),
        ("pp_ocrv6_medium_det", "PPOCRV6MediumDetForObjectDetection"),
        ("pp_ocrv6_small_det", "PPOCRV6SmallDetForObjectDetection"),
        ("rf_detr", "RfDetrForObjectDetection"),
        ("rt_detr", "RTDetrForObjectDetection"),
        ("rt_detr_v2", "RTDetrV2ForObjectDetection"),
        ("table-transformer", "TableTransformerForObjectDetection"),
        ("yolos", "YolosForObjectDetection"),
    ]
)

MODEL_FOR_ZERO_SHOT_OBJECT_DETECTION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Zero Shot Object Detection mapping
        ("grounding-dino", "GroundingDinoForObjectDetection"),
        ("mm-grounding-dino", "MMGroundingDinoForObjectDetection"),
        ("omdet-turbo", "OmDetTurboForObjectDetection"),
        ("owlv2", "Owlv2ForObjectDetection"),
        ("owlvit", "OwlViTForObjectDetection"),
    ]
)

MODEL_FOR_DEPTH_ESTIMATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for depth estimation mapping
        ("chmv2", "CHMv2ForDepthEstimation"),
        ("depth_anything", "DepthAnythingForDepthEstimation"),
        ("depth_pro", "DepthProForDepthEstimation"),
        ("dpt", "DPTForDepthEstimation"),
        ("glpn", "GLPNForDepthEstimation"),
        ("prompt_depth_anything", "PromptDepthAnythingForDepthEstimation"),
        ("tipsv2_dpt", "Tipsv2DptForDepthEstimation"),
        ("zoedepth", "ZoeDepthForDepthEstimation"),
    ]
)


MODEL_FOR_TEXT_RECOGNITION_MAPPING_NAMES = OrderedDict(
    [
        ("pp_ocrv5_mobile_rec", "PPOCRV5MobileRecForTextRecognition"),
        ("pp_ocrv5_server_rec", "PPOCRV5ServerRecForTextRecognition"),
        ("pp_ocrv6_small_rec", "PPOCRV6SmallRecForTextRecognition"),
        ("pp_ocrv6_tiny_rec", "PPOCRV6TinyRecForTextRecognition"),
    ]
)


MODEL_FOR_TABLE_RECOGNITION_MAPPING_NAMES = OrderedDict(
    [
        ("slanet", "SLANetForTableRecognition"),
        ("slanext", "SLANeXtForTableRecognition"),
    ]
)


MODEL_FOR_SEQ_TO_SEQ_CAUSAL_LM_MAPPING_NAMES = OrderedDict(
    [
        # Model for Seq2Seq Causal LM mapping
        ("audioflamingo3", "AudioFlamingo3ForConditionalGeneration"),
        ("bart", "BartForConditionalGeneration"),
        ("bigbird_pegasus", "BigBirdPegasusForConditionalGeneration"),
        ("blenderbot", "BlenderbotForConditionalGeneration"),
        ("blenderbot-small", "BlenderbotSmallForConditionalGeneration"),
        ("encoder-decoder", "EncoderDecoderModel"),
        ("fsmt", "FSMTForConditionalGeneration"),
        ("glmasr", "GlmAsrForConditionalGeneration"),
        ("granite_speech", "GraniteSpeechForConditionalGeneration"),
        ("granite_speech_plus", "GraniteSpeechPlusForConditionalGeneration"),
        ("led", "LEDForConditionalGeneration"),
        ("longt5", "LongT5ForConditionalGeneration"),
        ("m2m_100", "M2M100ForConditionalGeneration"),
        ("marian", "MarianMTModel"),
        ("mbart", "MBartForConditionalGeneration"),
        ("moss_transcribe_diarize", "MossTranscribeDiarizeForConditionalGeneration"),
        ("mt5", "MT5ForConditionalGeneration"),
        ("musicflamingo", "MusicFlamingoForConditionalGeneration"),
        ("mvp", "MvpForConditionalGeneration"),
        ("nllb-moe", "NllbMoeForConditionalGeneration"),
        ("pegasus", "PegasusForConditionalGeneration"),
        ("pegasus_x", "PegasusXForConditionalGeneration"),
        ("plbart", "PLBartForConditionalGeneration"),
        ("prophetnet", "ProphetNetForConditionalGeneration"),
        ("qwen2_audio", "Qwen2AudioForConditionalGeneration"),
        ("qwen3_asr", "Qwen3ASRForConditionalGeneration"),
        ("seamless_m4t", "SeamlessM4TForTextToText"),
        ("seamless_m4t_v2", "SeamlessM4Tv2ForTextToText"),
        ("switch_transformers", "SwitchTransformersForConditionalGeneration"),
        ("t5", "T5ForConditionalGeneration"),
        ("t5gemma", "T5GemmaForConditionalGeneration"),
        ("t5gemma2", "T5Gemma2ForConditionalGeneration"),
        ("umt5", "UMT5ForConditionalGeneration"),
        ("vibevoice_asr", "VibeVoiceAsrForConditionalGeneration"),
        ("voxtral", "VoxtralForConditionalGeneration"),
        ("voxtral_realtime", "VoxtralRealtimeForConditionalGeneration"),
    ]
)


MODEL_FOR_SPEECH_SEQ_2_SEQ_MAPPING_NAMES = OrderedDict(
    [
        ("canary", "CanaryForConditionalGeneration"),
        ("cohere_asr", "CohereAsrForConditionalGeneration"),
        ("dia", "DiaForConditionalGeneration"),
        ("fun_asr_nano", "FunAsrNanoForConditionalGeneration"),
        ("granite_speech", "GraniteSpeechForConditionalGeneration"),
        ("granite_speech_plus", "GraniteSpeechPlusForConditionalGeneration"),
        ("kyutai_speech_to_text", "KyutaiSpeechToTextForConditionalGeneration"),
        ("moonshine", "MoonshineForConditionalGeneration"),
        ("moonshine_streaming", "MoonshineStreamingForConditionalGeneration"),
        ("pop2piano", "Pop2PianoForConditionalGeneration"),
        ("qwen3_asr", "Qwen3ASRForConditionalGeneration"),
        ("seamless_m4t", "SeamlessM4TForSpeechToText"),
        ("seamless_m4t_v2", "SeamlessM4Tv2ForSpeechToText"),
        ("speech-encoder-decoder", "SpeechEncoderDecoderModel"),
        ("speech_to_text", "Speech2TextForConditionalGeneration"),
        ("speecht5", "SpeechT5ForSpeechToText"),
        ("vibevoice", "VibeVoiceForConditionalGeneration"),
        ("vibevoice_asr", "VibeVoiceAsrForConditionalGeneration"),
        ("voxtral", "VoxtralForConditionalGeneration"),
        ("voxtral_realtime", "VoxtralRealtimeForConditionalGeneration"),
        ("whisper", "WhisperForConditionalGeneration"),
    ]
)

MODEL_FOR_SEQUENCE_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Sequence Classification mapping
        ("albert", "AlbertForSequenceClassification"),
        ("arcee", "ArceeForSequenceClassification"),
        ("axk1", "AXK1ForSequenceClassification"),
        ("axk2", "AXK2ForSequenceClassification"),
        ("bart", "BartForSequenceClassification"),
        ("bert", "BertForSequenceClassification"),
        ("big_bird", "BigBirdForSequenceClassification"),
        ("bigbird_pegasus", "BigBirdPegasusForSequenceClassification"),
        ("biogpt", "BioGptForSequenceClassification"),
        ("bloom", "BloomForSequenceClassification"),
        ("camembert", "CamembertForSequenceClassification"),
        ("canine", "CanineForSequenceClassification"),
        ("cohere_compass_text", "CohereCompassTextForSequenceClassification"),
        ("convbert", "ConvBertForSequenceClassification"),
        ("ctrl", "CTRLForSequenceClassification"),
        ("data2vec-text", "Data2VecTextForSequenceClassification"),
        ("deberta", "DebertaForSequenceClassification"),
        ("deberta-v2", "DebertaV2ForSequenceClassification"),
        ("deepseek_v2", "DeepseekV2ForSequenceClassification"),
        ("deepseek_v3", "DeepseekV3ForSequenceClassification"),
        ("diffllama", "DiffLlamaForSequenceClassification"),
        ("distilbert", "DistilBertForSequenceClassification"),
        ("doge", "DogeForSequenceClassification"),
        ("electra", "ElectraForSequenceClassification"),
        ("ernie", "ErnieForSequenceClassification"),
        ("esm", "EsmForSequenceClassification"),
        ("esmc", "EsmcForSequenceClassification"),
        ("eurobert", "EuroBertForSequenceClassification"),
        ("exaone4", "Exaone4ForSequenceClassification"),
        ("falcon", "FalconForSequenceClassification"),
        ("flaubert", "FlaubertForSequenceClassification"),
        ("fnet", "FNetForSequenceClassification"),
        ("funnel", "FunnelForSequenceClassification"),
        ("gemma", "GemmaForSequenceClassification"),
        ("gemma2", "Gemma2ForSequenceClassification"),
        ("gemma3", "Gemma3ForSequenceClassification"),
        ("gemma3_text", "Gemma3TextForSequenceClassification"),
        ("glm", "GlmForSequenceClassification"),
        ("glm4", "Glm4ForSequenceClassification"),
        ("gpt-sw3", "GPT2ForSequenceClassification"),
        ("gpt2", "GPT2ForSequenceClassification"),
        ("gpt_bigcode", "GPTBigCodeForSequenceClassification"),
        ("gpt_neo", "GPTNeoForSequenceClassification"),
        ("gpt_neox", "GPTNeoXForSequenceClassification"),
        ("gpt_oss", "GptOssForSequenceClassification"),
        ("gptj", "GPTJForSequenceClassification"),
        ("gte", "GteForSequenceClassification"),
        ("helium", "HeliumForSequenceClassification"),
        ("hunyuan_v1_dense", "HunYuanDenseV1ForSequenceClassification"),
        ("hunyuan_v1_moe", "HunYuanMoEV1ForSequenceClassification"),
        ("ibert", "IBertForSequenceClassification"),
        ("jamba", "JambaForSequenceClassification"),
        ("jetmoe", "JetMoeForSequenceClassification"),
        ("jina_embeddings_v3", "JinaEmbeddingsV3ForSequenceClassification"),
        ("layoutlm", "LayoutLMForSequenceClassification"),
        ("layoutlmv2", "LayoutLMv2ForSequenceClassification"),
        ("layoutlmv3", "LayoutLMv3ForSequenceClassification"),
        ("lilt", "LiltForSequenceClassification"),
        ("llama", "LlamaForSequenceClassification"),
        ("longformer", "LongformerForSequenceClassification"),
        ("luke", "LukeForSequenceClassification"),
        ("markuplm", "MarkupLMForSequenceClassification"),
        ("mbart", "MBartForSequenceClassification"),
        ("megatron-bert", "MegatronBertForSequenceClassification"),
        ("minicpm3", "MiniCPM3ForSequenceClassification"),
        ("minimax", "MiniMaxForSequenceClassification"),
        ("ministral", "MinistralForSequenceClassification"),
        ("ministral3", "Ministral3ForSequenceClassification"),
        ("mistral", "MistralForSequenceClassification"),
        ("mistral4", "Mistral4ForSequenceClassification"),
        ("mixtral", "MixtralForSequenceClassification"),
        ("mobilebert", "MobileBertForSequenceClassification"),
        ("modernbert", "ModernBertForSequenceClassification"),
        ("modernbert-decoder", "ModernBertDecoderForSequenceClassification"),
        ("modernvbert", "ModernVBertForSequenceClassification"),
        ("mpnet", "MPNetForSequenceClassification"),
        ("mpt", "MptForSequenceClassification"),
        ("mra", "MraForSequenceClassification"),
        ("mt5", "MT5ForSequenceClassification"),
        ("mvp", "MvpForSequenceClassification"),
        ("nemotron", "NemotronForSequenceClassification"),
        ("nomic_bert", "NomicBertForSequenceClassification"),
        ("nystromformer", "NystromformerForSequenceClassification"),
        ("olmo", "OlmoForSequenceClassification"),
        ("olmo2", "Olmo2ForSequenceClassification"),
        ("olmo3", "Olmo3ForSequenceClassification"),
        ("openai-gpt", "OpenAIGPTForSequenceClassification"),
        ("opt", "OPTForSequenceClassification"),
        ("perceiver", "PerceiverForSequenceClassification"),
        ("persimmon", "PersimmonForSequenceClassification"),
        ("phi", "PhiForSequenceClassification"),
        ("phi3", "Phi3ForSequenceClassification"),
        ("phimoe", "PhimoeForSequenceClassification"),
        ("plbart", "PLBartForSequenceClassification"),
        ("qwen2", "Qwen2ForSequenceClassification"),
        ("qwen2_moe", "Qwen2MoeForSequenceClassification"),
        ("qwen3", "Qwen3ForSequenceClassification"),
        ("qwen3_5", "Qwen3_5ForSequenceClassification"),
        ("qwen3_5_text", "Qwen3_5TextForSequenceClassification"),
        ("qwen3_moe", "Qwen3MoeForSequenceClassification"),
        ("qwen3_next", "Qwen3NextForSequenceClassification"),
        ("reformer", "ReformerForSequenceClassification"),
        ("rembert", "RemBertForSequenceClassification"),
        ("roberta", "RobertaForSequenceClassification"),
        ("roberta-prelayernorm", "RobertaPreLayerNormForSequenceClassification"),
        ("roc_bert", "RoCBertForSequenceClassification"),
        ("roformer", "RoFormerForSequenceClassification"),
        ("seed_oss", "SeedOssForSequenceClassification"),
        ("smollm3", "SmolLM3ForSequenceClassification"),
        ("squeezebert", "SqueezeBertForSequenceClassification"),
        ("stablelm", "StableLmForSequenceClassification"),
        ("starcoder2", "Starcoder2ForSequenceClassification"),
        ("t5", "T5ForSequenceClassification"),
        ("t5gemma", "T5GemmaForSequenceClassification"),
        ("t5gemma2", "T5Gemma2ForSequenceClassification"),
        ("tapas", "TapasForSequenceClassification"),
        ("ultrabert", "UltrabertForSequenceClassification"),
        ("umt5", "UMT5ForSequenceClassification"),
        ("xlm", "XLMForSequenceClassification"),
        ("xlm-roberta", "XLMRobertaForSequenceClassification"),
        ("xlm-roberta-xl", "XLMRobertaXLForSequenceClassification"),
        ("xlnet", "XLNetForSequenceClassification"),
        ("xmod", "XmodForSequenceClassification"),
        ("yoso", "YosoForSequenceClassification"),
        ("zamba", "ZambaForSequenceClassification"),
        ("zamba2", "Zamba2ForSequenceClassification"),
    ]
)

MODEL_FOR_QUESTION_ANSWERING_MAPPING_NAMES = OrderedDict(
    [
        # Model for Question Answering mapping
        ("albert", "AlbertForQuestionAnswering"),
        ("arcee", "ArceeForQuestionAnswering"),
        ("bart", "BartForQuestionAnswering"),
        ("bert", "BertForQuestionAnswering"),
        ("big_bird", "BigBirdForQuestionAnswering"),
        ("bigbird_pegasus", "BigBirdPegasusForQuestionAnswering"),
        ("bloom", "BloomForQuestionAnswering"),
        ("camembert", "CamembertForQuestionAnswering"),
        ("canine", "CanineForQuestionAnswering"),
        ("convbert", "ConvBertForQuestionAnswering"),
        ("data2vec-text", "Data2VecTextForQuestionAnswering"),
        ("deberta", "DebertaForQuestionAnswering"),
        ("deberta-v2", "DebertaV2ForQuestionAnswering"),
        ("diffllama", "DiffLlamaForQuestionAnswering"),
        ("distilbert", "DistilBertForQuestionAnswering"),
        ("electra", "ElectraForQuestionAnswering"),
        ("ernie", "ErnieForQuestionAnswering"),
        ("exaone4", "Exaone4ForQuestionAnswering"),
        ("falcon", "FalconForQuestionAnswering"),
        ("flaubert", "FlaubertForQuestionAnsweringSimple"),
        ("fnet", "FNetForQuestionAnswering"),
        ("funnel", "FunnelForQuestionAnswering"),
        ("gpt2", "GPT2ForQuestionAnswering"),
        ("gpt_neo", "GPTNeoForQuestionAnswering"),
        ("gpt_neox", "GPTNeoXForQuestionAnswering"),
        ("gptj", "GPTJForQuestionAnswering"),
        ("ibert", "IBertForQuestionAnswering"),
        ("jina_embeddings_v3", "JinaEmbeddingsV3ForQuestionAnswering"),
        ("layoutlmv2", "LayoutLMv2ForQuestionAnswering"),
        ("layoutlmv3", "LayoutLMv3ForQuestionAnswering"),
        ("led", "LEDForQuestionAnswering"),
        ("lilt", "LiltForQuestionAnswering"),
        ("llama", "LlamaForQuestionAnswering"),
        ("longformer", "LongformerForQuestionAnswering"),
        ("luke", "LukeForQuestionAnswering"),
        ("lxmert", "LxmertForQuestionAnswering"),
        ("markuplm", "MarkupLMForQuestionAnswering"),
        ("mbart", "MBartForQuestionAnswering"),
        ("megatron-bert", "MegatronBertForQuestionAnswering"),
        ("minimax", "MiniMaxForQuestionAnswering"),
        ("ministral", "MinistralForQuestionAnswering"),
        ("ministral3", "Ministral3ForQuestionAnswering"),
        ("mistral", "MistralForQuestionAnswering"),
        ("mixtral", "MixtralForQuestionAnswering"),
        ("mobilebert", "MobileBertForQuestionAnswering"),
        ("modernbert", "ModernBertForQuestionAnswering"),
        ("mpnet", "MPNetForQuestionAnswering"),
        ("mpt", "MptForQuestionAnswering"),
        ("mra", "MraForQuestionAnswering"),
        ("mt5", "MT5ForQuestionAnswering"),
        ("mvp", "MvpForQuestionAnswering"),
        ("nemotron", "NemotronForQuestionAnswering"),
        ("nystromformer", "NystromformerForQuestionAnswering"),
        ("opt", "OPTForQuestionAnswering"),
        ("qwen2", "Qwen2ForQuestionAnswering"),
        ("qwen2_moe", "Qwen2MoeForQuestionAnswering"),
        ("qwen3", "Qwen3ForQuestionAnswering"),
        ("qwen3_moe", "Qwen3MoeForQuestionAnswering"),
        ("qwen3_next", "Qwen3NextForQuestionAnswering"),
        ("reformer", "ReformerForQuestionAnswering"),
        ("rembert", "RemBertForQuestionAnswering"),
        ("roberta", "RobertaForQuestionAnswering"),
        ("roberta-prelayernorm", "RobertaPreLayerNormForQuestionAnswering"),
        ("roc_bert", "RoCBertForQuestionAnswering"),
        ("roformer", "RoFormerForQuestionAnswering"),
        ("seed_oss", "SeedOssForQuestionAnswering"),
        ("smollm3", "SmolLM3ForQuestionAnswering"),
        ("splinter", "SplinterForQuestionAnswering"),
        ("squeezebert", "SqueezeBertForQuestionAnswering"),
        ("t5", "T5ForQuestionAnswering"),
        ("ultrabert", "UltrabertForQuestionAnswering"),
        ("umt5", "UMT5ForQuestionAnswering"),
        ("xlm", "XLMForQuestionAnsweringSimple"),
        ("xlm-roberta", "XLMRobertaForQuestionAnswering"),
        ("xlm-roberta-xl", "XLMRobertaXLForQuestionAnswering"),
        ("xlnet", "XLNetForQuestionAnsweringSimple"),
        ("xmod", "XmodForQuestionAnswering"),
        ("yoso", "YosoForQuestionAnswering"),
    ]
)

MODEL_FOR_TABLE_QUESTION_ANSWERING_MAPPING_NAMES = OrderedDict(
    [
        # Model for Table Question Answering mapping
        ("tapas", "TapasForQuestionAnswering"),
    ]
)

MODEL_FOR_VISUAL_QUESTION_ANSWERING_MAPPING_NAMES = OrderedDict(
    [
        ("blip", "BlipForQuestionAnswering"),
        ("blip-2", "Blip2ForConditionalGeneration"),
        ("vilt", "ViltForQuestionAnswering"),
    ]
)

MODEL_FOR_DOCUMENT_QUESTION_ANSWERING_MAPPING_NAMES = OrderedDict(
    [
        ("layoutlm", "LayoutLMForQuestionAnswering"),
        ("layoutlmv2", "LayoutLMv2ForQuestionAnswering"),
        ("layoutlmv3", "LayoutLMv3ForQuestionAnswering"),
    ]
)

MODEL_FOR_TOKEN_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Token Classification mapping
        ("albert", "AlbertForTokenClassification"),
        ("apertus", "ApertusForTokenClassification"),
        ("arcee", "ArceeForTokenClassification"),
        ("axk1", "AXK1ForTokenClassification"),
        ("axk2", "AXK2ForTokenClassification"),
        ("bert", "BertForTokenClassification"),
        ("big_bird", "BigBirdForTokenClassification"),
        ("biogpt", "BioGptForTokenClassification"),
        ("bloom", "BloomForTokenClassification"),
        ("bros", "BrosForTokenClassification"),
        ("camembert", "CamembertForTokenClassification"),
        ("canine", "CanineForTokenClassification"),
        ("convbert", "ConvBertForTokenClassification"),
        ("data2vec-text", "Data2VecTextForTokenClassification"),
        ("deberta", "DebertaForTokenClassification"),
        ("deberta-v2", "DebertaV2ForTokenClassification"),
        ("deepseek_v3", "DeepseekV3ForTokenClassification"),
        ("diffllama", "DiffLlamaForTokenClassification"),
        ("distilbert", "DistilBertForTokenClassification"),
        ("electra", "ElectraForTokenClassification"),
        ("ernie", "ErnieForTokenClassification"),
        ("esm", "EsmForTokenClassification"),
        ("esmc", "EsmcForTokenClassification"),
        ("eurobert", "EuroBertForTokenClassification"),
        ("exaone4", "Exaone4ForTokenClassification"),
        ("falcon", "FalconForTokenClassification"),
        ("flaubert", "FlaubertForTokenClassification"),
        ("fnet", "FNetForTokenClassification"),
        ("funnel", "FunnelForTokenClassification"),
        ("gemma", "GemmaForTokenClassification"),
        ("gemma2", "Gemma2ForTokenClassification"),
        ("glm", "GlmForTokenClassification"),
        ("glm4", "Glm4ForTokenClassification"),
        ("gpt-sw3", "GPT2ForTokenClassification"),
        ("gpt2", "GPT2ForTokenClassification"),
        ("gpt_bigcode", "GPTBigCodeForTokenClassification"),
        ("gpt_neo", "GPTNeoForTokenClassification"),
        ("gpt_neox", "GPTNeoXForTokenClassification"),
        ("gpt_oss", "GptOssForTokenClassification"),
        ("gte", "GteForTokenClassification"),
        ("helium", "HeliumForTokenClassification"),
        ("ibert", "IBertForTokenClassification"),
        ("jina_embeddings_v3", "JinaEmbeddingsV3ForTokenClassification"),
        ("layoutlm", "LayoutLMForTokenClassification"),
        ("layoutlmv2", "LayoutLMv2ForTokenClassification"),
        ("layoutlmv3", "LayoutLMv3ForTokenClassification"),
        ("lilt", "LiltForTokenClassification"),
        ("llama", "LlamaForTokenClassification"),
        ("longformer", "LongformerForTokenClassification"),
        ("luke", "LukeForTokenClassification"),
        ("markuplm", "MarkupLMForTokenClassification"),
        ("megatron-bert", "MegatronBertForTokenClassification"),
        ("minimax", "MiniMaxForTokenClassification"),
        ("ministral", "MinistralForTokenClassification"),
        ("ministral3", "Ministral3ForTokenClassification"),
        ("mistral", "MistralForTokenClassification"),
        ("mistral4", "Mistral4ForTokenClassification"),
        ("mixtral", "MixtralForTokenClassification"),
        ("mobilebert", "MobileBertForTokenClassification"),
        ("modernbert", "ModernBertForTokenClassification"),
        ("modernvbert", "ModernVBertForTokenClassification"),
        ("mpnet", "MPNetForTokenClassification"),
        ("mpt", "MptForTokenClassification"),
        ("mra", "MraForTokenClassification"),
        ("mt5", "MT5ForTokenClassification"),
        ("nemotron", "NemotronForTokenClassification"),
        ("nomic_bert", "NomicBertForTokenClassification"),
        ("nystromformer", "NystromformerForTokenClassification"),
        ("openai_privacy_filter", "OpenAIPrivacyFilterForTokenClassification"),
        ("persimmon", "PersimmonForTokenClassification"),
        ("phi", "PhiForTokenClassification"),
        ("phi3", "Phi3ForTokenClassification"),
        ("qwen2", "Qwen2ForTokenClassification"),
        ("qwen2_moe", "Qwen2MoeForTokenClassification"),
        ("qwen3", "Qwen3ForTokenClassification"),
        ("qwen3_5", "Qwen3_5ForTokenClassification"),
        ("qwen3_asr", "Qwen3ASRForTokenClassification"),
        ("qwen3_moe", "Qwen3MoeForTokenClassification"),
        ("qwen3_next", "Qwen3NextForTokenClassification"),
        ("rembert", "RemBertForTokenClassification"),
        ("roberta", "RobertaForTokenClassification"),
        ("roberta-prelayernorm", "RobertaPreLayerNormForTokenClassification"),
        ("roc_bert", "RoCBertForTokenClassification"),
        ("roformer", "RoFormerForTokenClassification"),
        ("seed_oss", "SeedOssForTokenClassification"),
        ("smollm3", "SmolLM3ForTokenClassification"),
        ("squeezebert", "SqueezeBertForTokenClassification"),
        ("stablelm", "StableLmForTokenClassification"),
        ("starcoder2", "Starcoder2ForTokenClassification"),
        ("t5", "T5ForTokenClassification"),
        ("t5gemma", "T5GemmaForTokenClassification"),
        ("t5gemma2", "T5Gemma2ForTokenClassification"),
        ("ultrabert", "UltrabertForTokenClassification"),
        ("umt5", "UMT5ForTokenClassification"),
        ("xlm", "XLMForTokenClassification"),
        ("xlm-roberta", "XLMRobertaForTokenClassification"),
        ("xlm-roberta-xl", "XLMRobertaXLForTokenClassification"),
        ("xlnet", "XLNetForTokenClassification"),
        ("xmod", "XmodForTokenClassification"),
        ("yoso", "YosoForTokenClassification"),
    ]
)

MODEL_FOR_MULTIPLE_CHOICE_MAPPING_NAMES = OrderedDict(
    [
        # Model for Multiple Choice mapping
        ("albert", "AlbertForMultipleChoice"),
        ("bert", "BertForMultipleChoice"),
        ("big_bird", "BigBirdForMultipleChoice"),
        ("camembert", "CamembertForMultipleChoice"),
        ("canine", "CanineForMultipleChoice"),
        ("convbert", "ConvBertForMultipleChoice"),
        ("data2vec-text", "Data2VecTextForMultipleChoice"),
        ("deberta-v2", "DebertaV2ForMultipleChoice"),
        ("distilbert", "DistilBertForMultipleChoice"),
        ("electra", "ElectraForMultipleChoice"),
        ("ernie", "ErnieForMultipleChoice"),
        ("flaubert", "FlaubertForMultipleChoice"),
        ("fnet", "FNetForMultipleChoice"),
        ("funnel", "FunnelForMultipleChoice"),
        ("ibert", "IBertForMultipleChoice"),
        ("longformer", "LongformerForMultipleChoice"),
        ("luke", "LukeForMultipleChoice"),
        ("megatron-bert", "MegatronBertForMultipleChoice"),
        ("mobilebert", "MobileBertForMultipleChoice"),
        ("modernbert", "ModernBertForMultipleChoice"),
        ("mpnet", "MPNetForMultipleChoice"),
        ("mra", "MraForMultipleChoice"),
        ("nystromformer", "NystromformerForMultipleChoice"),
        ("rembert", "RemBertForMultipleChoice"),
        ("roberta", "RobertaForMultipleChoice"),
        ("roberta-prelayernorm", "RobertaPreLayerNormForMultipleChoice"),
        ("roc_bert", "RoCBertForMultipleChoice"),
        ("roformer", "RoFormerForMultipleChoice"),
        ("squeezebert", "SqueezeBertForMultipleChoice"),
        ("xlm", "XLMForMultipleChoice"),
        ("xlm-roberta", "XLMRobertaForMultipleChoice"),
        ("xlm-roberta-xl", "XLMRobertaXLForMultipleChoice"),
        ("xlnet", "XLNetForMultipleChoice"),
        ("xmod", "XmodForMultipleChoice"),
        ("yoso", "YosoForMultipleChoice"),
    ]
)

MODEL_FOR_NEXT_SENTENCE_PREDICTION_MAPPING_NAMES = OrderedDict(
    [
        ("bert", "BertForNextSentencePrediction"),
        ("ernie", "ErnieForNextSentencePrediction"),
        ("fnet", "FNetForNextSentencePrediction"),
        ("megatron-bert", "MegatronBertForNextSentencePrediction"),
        ("mobilebert", "MobileBertForNextSentencePrediction"),
    ]
)

MODEL_FOR_AUDIO_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Audio Classification mapping
        ("audio-spectrogram-transformer", "ASTForAudioClassification"),
        ("data2vec-audio", "Data2VecAudioForSequenceClassification"),
        ("hubert", "HubertForSequenceClassification"),
        ("sew", "SEWForSequenceClassification"),
        ("sew-d", "SEWDForSequenceClassification"),
        ("unispeech", "UniSpeechForSequenceClassification"),
        ("unispeech-sat", "UniSpeechSatForSequenceClassification"),
        ("wav2vec2", "Wav2Vec2ForSequenceClassification"),
        ("wav2vec2-bert", "Wav2Vec2BertForSequenceClassification"),
        ("wav2vec2-conformer", "Wav2Vec2ConformerForSequenceClassification"),
        ("wavlm", "WavLMForSequenceClassification"),
        ("whisper", "WhisperForAudioClassification"),
    ]
)

MODEL_FOR_CTC_MAPPING_NAMES = OrderedDict(
    [
        # Model for Connectionist temporal classification (CTC) mapping
        ("data2vec-audio", "Data2VecAudioForCTC"),
        ("granite_speech5_ctc", "GraniteSpeech5ForCTC"),
        ("hubert", "HubertForCTC"),
        ("lasr_ctc", "LasrForCTC"),
        ("parakeet_ctc", "ParakeetForCTC"),
        ("sew", "SEWForCTC"),
        ("sew-d", "SEWDForCTC"),
        ("unispeech", "UniSpeechForCTC"),
        ("unispeech-sat", "UniSpeechSatForCTC"),
        ("wav2vec2", "Wav2Vec2ForCTC"),
        ("wav2vec2-bert", "Wav2Vec2BertForCTC"),
        ("wav2vec2-conformer", "Wav2Vec2ConformerForCTC"),
        ("wavlm", "WavLMForCTC"),
    ]
)

MODEL_FOR_RNNT_MAPPING_NAMES = OrderedDict(
    [
        # Model for RNN Transducer (RNN-T) mapping.
        ("nemotron3_5_asr", "Nemotron3_5AsrForRNNT"),
        ("nemotron_asr_streaming", "NemotronAsrStreamingForRNNT"),
        ("parakeet_rnnt", "ParakeetForRNNT"),
    ]
)

MODEL_FOR_TDT_MAPPING_NAMES = OrderedDict(
    [
        # Model for Token-and-Duration Transducer (TDT) mapping.
        ("parakeet_tdt", "ParakeetForTDT"),
    ]
)


MODEL_FOR_AUDIO_FRAME_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Audio Classification mapping
        ("data2vec-audio", "Data2VecAudioForAudioFrameClassification"),
        ("nemotron3_diarization", "Nemotron3DiarizationForAudioFrameClassification"),
        ("unispeech-sat", "UniSpeechSatForAudioFrameClassification"),
        ("wav2vec2", "Wav2Vec2ForAudioFrameClassification"),
        ("wav2vec2-bert", "Wav2Vec2BertForAudioFrameClassification"),
        ("wav2vec2-conformer", "Wav2Vec2ConformerForAudioFrameClassification"),
        ("wavlm", "WavLMForAudioFrameClassification"),
    ]
)

MODEL_FOR_AUDIO_XVECTOR_MAPPING_NAMES = OrderedDict(
    [
        # Model for Audio Classification mapping
        ("data2vec-audio", "Data2VecAudioForXVector"),
        ("unispeech-sat", "UniSpeechSatForXVector"),
        ("wav2vec2", "Wav2Vec2ForXVector"),
        ("wav2vec2-bert", "Wav2Vec2BertForXVector"),
        ("wav2vec2-conformer", "Wav2Vec2ConformerForXVector"),
        ("wavlm", "WavLMForXVector"),
    ]
)

MODEL_FOR_TEXT_TO_SPECTROGRAM_MAPPING_NAMES = OrderedDict(
    [
        # Model for Text-To-Spectrogram mapping
        ("fastspeech2_conformer", "FastSpeech2ConformerModel"),
        ("speecht5", "SpeechT5ForTextToSpeech"),
    ]
)

MODEL_FOR_TEXT_TO_WAVEFORM_MAPPING_NAMES = OrderedDict(
    [
        # Model for Text-To-Waveform mapping
        ("bark", "BarkModel"),
        ("csm", "CsmForConditionalGeneration"),
        ("fastspeech2_conformer_with_hifigan", "FastSpeech2ConformerWithHifiGan"),
        ("higgs_audio_v2", "HiggsAudioV2ForConditionalGeneration"),
        ("musicgen", "MusicgenForConditionalGeneration"),
        ("musicgen_melody", "MusicgenMelodyForConditionalGeneration"),
        ("qwen2_5_omni", "Qwen2_5OmniForConditionalGeneration"),
        ("qwen3_omni_moe", "Qwen3OmniMoeForConditionalGeneration"),
        ("seamless_m4t", "SeamlessM4TForTextToSpeech"),
        ("seamless_m4t_v2", "SeamlessM4Tv2ForTextToSpeech"),
        ("vibevoice", "VibeVoiceForConditionalGeneration"),
        ("vits", "VitsModel"),
    ]
)

MODEL_FOR_ZERO_SHOT_IMAGE_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        # Model for Zero Shot Image Classification mapping
        ("align", "AlignModel"),
        ("altclip", "AltCLIPModel"),
        ("blip", "BlipModel"),
        ("blip-2", "Blip2ForImageTextRetrieval"),
        ("chinese_clip", "ChineseCLIPModel"),
        ("clip", "CLIPModel"),
        ("clipseg", "CLIPSegModel"),
        ("metaclip_2", "MetaClip2Model"),
        ("siglip", "SiglipModel"),
        ("siglip2", "Siglip2Model"),
        ("tipsv2", "Tipsv2Model"),
        ("videoprism", "VideoPrismClipModel"),
    ]
)

MODEL_FOR_BACKBONE_MAPPING_NAMES = OrderedDict(
    [
        # Backbone mapping
        ("beit", "BeitBackbone"),
        ("bit", "BitBackbone"),
        ("convnext", "ConvNextBackbone"),
        ("convnextv2", "ConvNextV2Backbone"),
        ("dinat", "DinatBackbone"),
        ("dinov2", "Dinov2Backbone"),
        ("dinov2_with_registers", "Dinov2WithRegistersBackbone"),
        ("dinov3_convnext", "DINOv3ConvNextBackbone"),
        ("dinov3_vit", "DINOv3ViTBackbone"),
        ("focalnet", "FocalNetBackbone"),
        ("hgnet_v2", "HGNetV2Backbone"),
        ("hiera", "HieraBackbone"),
        ("lw_detr_vit", "LwDetrViTBackbone"),
        ("maskformer-swin", "MaskFormerSwinBackbone"),
        ("pixio", "PixioBackbone"),
        ("pp_lcnet", "PPLCNetBackbone"),
        ("pp_lcnet_v3", "PPLCNetV3Backbone"),
        ("pp_lcnet_v4", "PPLCNetV4Backbone"),
        ("pvt_v2", "PvtV2Backbone"),
        ("resnet", "ResNetBackbone"),
        ("rf_detr_dinov2", "RfDetrDinov2Backbone"),
        ("rt_detr_resnet", "RTDetrResNetBackbone"),
        ("sapiens2", "Sapiens2Backbone"),
        ("swin", "SwinBackbone"),
        ("swinv2", "Swinv2Backbone"),
        ("textnet", "TextNetBackbone"),
        ("timm_backbone", "TimmBackbone"),
        ("tipsv2", "Tipsv2VisionBackbone"),
        ("tipsv2_vision_model", "Tipsv2VisionBackbone"),
        ("uvdoc_backbone", "UVDocBackbone"),
        ("vitdet", "VitDetBackbone"),
        ("vitpose_backbone", "VitPoseBackbone"),
    ]
)

MODEL_FOR_MASK_GENERATION_MAPPING_NAMES = OrderedDict(
    [
        ("edgetam", "EdgeTamModel"),
        ("edgetam_video", "EdgeTamModel"),
        ("sam", "SamModel"),
        ("sam2", "Sam2Model"),
        ("sam2_video", "Sam2Model"),
        ("sam3_tracker", "Sam3TrackerModel"),
        ("sam3_video", "Sam3TrackerModel"),
        ("sam_hq", "SamHQModel"),
    ]
)


MODEL_FOR_KEYPOINT_DETECTION_MAPPING_NAMES = OrderedDict(
    [
        ("superpoint", "SuperPointForKeypointDetection"),
    ]
)

MODEL_FOR_KEYPOINT_MATCHING_MAPPING_NAMES = OrderedDict(
    [
        ("efficientloftr", "EfficientLoFTRForKeypointMatching"),
        ("lightglue", "LightGlueForKeypointMatching"),
        ("superglue", "SuperGlueForKeypointMatching"),
    ]
)

MODEL_FOR_TEXT_ENCODING_MAPPING_NAMES = OrderedDict(
    [
        ("albert", "AlbertModel"),
        ("bert", "BertModel"),
        ("big_bird", "BigBirdModel"),
        ("clip_text_model", "CLIPTextModel"),
        ("data2vec-text", "Data2VecTextModel"),
        ("deberta", "DebertaModel"),
        ("deberta-v2", "DebertaV2Model"),
        ("distilbert", "DistilBertModel"),
        ("electra", "ElectraModel"),
        ("emu3", "Emu3TextModel"),
        ("flaubert", "FlaubertModel"),
        ("ibert", "IBertModel"),
        ("llama4", "Llama4TextModel"),
        ("longformer", "LongformerModel"),
        ("mllama", "MllamaTextModel"),
        ("mobilebert", "MobileBertModel"),
        ("molmo2_text", "Molmo2TextModel"),
        ("mt5", "MT5EncoderModel"),
        ("nystromformer", "NystromformerModel"),
        ("reformer", "ReformerModel"),
        ("rembert", "RemBertModel"),
        ("roberta", "RobertaModel"),
        ("roberta-prelayernorm", "RobertaPreLayerNormModel"),
        ("roc_bert", "RoCBertModel"),
        ("roformer", "RoFormerModel"),
        ("squeezebert", "SqueezeBertModel"),
        ("t5", "T5EncoderModel"),
        ("t5gemma", "T5GemmaEncoderModel"),
        ("tipsv2_text_model", "Tipsv2TextModel"),
        ("umt5", "UMT5EncoderModel"),
        ("xlm", "XLMModel"),
        ("xlm-roberta", "XLMRobertaModel"),
        ("xlm-roberta-xl", "XLMRobertaXLModel"),
    ]
)

MODEL_FOR_TIME_SERIES_CLASSIFICATION_MAPPING_NAMES = OrderedDict(
    [
        ("patchtsmixer", "PatchTSMixerForTimeSeriesClassification"),
        ("patchtst", "PatchTSTForClassification"),
    ]
)

MODEL_FOR_TIME_SERIES_REGRESSION_MAPPING_NAMES = OrderedDict(
    [
        ("patchtsmixer", "PatchTSMixerForRegression"),
        ("patchtst", "PatchTSTForRegression"),
    ]
)

MODEL_FOR_TIME_SERIES_PREDICTION_MAPPING_NAMES = OrderedDict(
    [
        ("timesfm", "TimesFmModelForPrediction"),
        ("timesfm2_5", "TimesFm2_5ModelForPrediction"),
    ]
)

MODEL_FOR_IMAGE_TO_IMAGE_MAPPING_NAMES = OrderedDict(
    [
        ("swin2sr", "Swin2SRForImageSuperResolution"),
    ]
)

MODEL_FOR_AUDIO_TOKENIZATION_NAMES = OrderedDict(
    [
        ("dac", "DacModel"),
        ("higgs_audio_v2_tokenizer", "HiggsAudioV2TokenizerModel"),
        ("neucodec", "NeuCodecModel"),
        ("vibevoice_acoustic_tokenizer", "VibeVoiceAcousticTokenizerModel"),
        ("xcodec2", "Xcodec2Model"),
    ]
)

MODEL_FOR_IMAGE_MATTING_MAPPING_NAMES = OrderedDict(
    [
        ("sapiens2", "Sapiens2ForImageMatting"),
        ("vitmatte", "VitMatteForImageMatting"),
    ]
)

MODEL_FOR_NORMAL_ESTIMATION_MAPPING_NAMES = OrderedDict(
    [
        ("sapiens2", "Sapiens2ForNormalEstimation"),
        ("tipsv2_dpt", "Tipsv2DptForNormalEstimation"),
    ]
)

MODEL_FOR_POINTMAP_ESTIMATION_MAPPING_NAMES = OrderedDict(
    [
        ("sapiens2", "Sapiens2ForPointmapEstimation"),
    ]
)

MODEL_FOR_POSE_ESTIMATION_MAPPING_NAMES = OrderedDict(
    [
        ("sapiens2", "Sapiens2ForPoseEstimation"),
        ("vitpose", "VitPoseForPoseEstimation"),
    ]
)


MODEL_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_MAPPING_NAMES)
MODEL_FOR_PRETRAINING_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_PRETRAINING_MAPPING_NAMES)
MODEL_FOR_CAUSAL_LM_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_CAUSAL_LM_MAPPING_NAMES)
MODEL_FOR_CAUSAL_IMAGE_MODELING_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_CAUSAL_IMAGE_MODELING_MAPPING_NAMES
)
MODEL_FOR_IMAGE_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_IMAGE_CLASSIFICATION_MAPPING_NAMES
)
MODEL_FOR_ZERO_SHOT_IMAGE_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_ZERO_SHOT_IMAGE_CLASSIFICATION_MAPPING_NAMES
)
MODEL_FOR_IMAGE_SEGMENTATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_IMAGE_SEGMENTATION_MAPPING_NAMES
)
MODEL_FOR_SEMANTIC_SEGMENTATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_SEMANTIC_SEGMENTATION_MAPPING_NAMES
)
MODEL_FOR_INSTANCE_SEGMENTATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_INSTANCE_SEGMENTATION_MAPPING_NAMES
)
MODEL_FOR_UNIVERSAL_SEGMENTATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_UNIVERSAL_SEGMENTATION_MAPPING_NAMES
)
MODEL_FOR_VIDEO_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_VIDEO_CLASSIFICATION_MAPPING_NAMES
)
MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES
)
MODEL_FOR_MULTIMODAL_LM_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_MULTIMODAL_LM_MAPPING_NAMES)
MODEL_FOR_RETRIEVAL_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_RETRIEVAL_MAPPING_NAMES)
MODEL_FOR_VISUAL_QUESTION_ANSWERING_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_VISUAL_QUESTION_ANSWERING_MAPPING_NAMES
)
MODEL_FOR_DOCUMENT_QUESTION_ANSWERING_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_DOCUMENT_QUESTION_ANSWERING_MAPPING_NAMES
)
MODEL_FOR_MASKED_LM_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_MASKED_LM_MAPPING_NAMES)
MODEL_FOR_IMAGE_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_IMAGE_MAPPING_NAMES)
MODEL_FOR_MASKED_IMAGE_MODELING_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_MASKED_IMAGE_MODELING_MAPPING_NAMES
)
MODEL_FOR_OBJECT_DETECTION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_OBJECT_DETECTION_MAPPING_NAMES)
MODEL_FOR_ZERO_SHOT_OBJECT_DETECTION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_ZERO_SHOT_OBJECT_DETECTION_MAPPING_NAMES
)
MODEL_FOR_DEPTH_ESTIMATION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_DEPTH_ESTIMATION_MAPPING_NAMES)
MODEL_FOR_TEXT_RECOGNITION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_TEXT_RECOGNITION_MAPPING_NAMES)
MODEL_FOR_TABLE_RECOGNITION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_TABLE_RECOGNITION_MAPPING_NAMES)
MODEL_FOR_SEQ_TO_SEQ_CAUSAL_LM_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_SEQ_TO_SEQ_CAUSAL_LM_MAPPING_NAMES
)
MODEL_FOR_SEQUENCE_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_SEQUENCE_CLASSIFICATION_MAPPING_NAMES
)
MODEL_FOR_QUESTION_ANSWERING_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_QUESTION_ANSWERING_MAPPING_NAMES
)
MODEL_FOR_TABLE_QUESTION_ANSWERING_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_TABLE_QUESTION_ANSWERING_MAPPING_NAMES
)
MODEL_FOR_TOKEN_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_TOKEN_CLASSIFICATION_MAPPING_NAMES
)
MODEL_FOR_MULTIPLE_CHOICE_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_MULTIPLE_CHOICE_MAPPING_NAMES)
MODEL_FOR_NEXT_SENTENCE_PREDICTION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_NEXT_SENTENCE_PREDICTION_MAPPING_NAMES
)
MODEL_FOR_AUDIO_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_AUDIO_CLASSIFICATION_MAPPING_NAMES
)
MODEL_FOR_CTC_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_CTC_MAPPING_NAMES)
MODEL_FOR_RNNT_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_RNNT_MAPPING_NAMES)
MODEL_FOR_TDT_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_TDT_MAPPING_NAMES)
MODEL_FOR_SPEECH_SEQ_2_SEQ_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_SPEECH_SEQ_2_SEQ_MAPPING_NAMES)
MODEL_FOR_AUDIO_FRAME_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_AUDIO_FRAME_CLASSIFICATION_MAPPING_NAMES
)
MODEL_FOR_AUDIO_XVECTOR_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_AUDIO_XVECTOR_MAPPING_NAMES)

MODEL_FOR_TEXT_TO_SPECTROGRAM_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_TEXT_TO_SPECTROGRAM_MAPPING_NAMES
)

MODEL_FOR_TEXT_TO_WAVEFORM_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_TEXT_TO_WAVEFORM_MAPPING_NAMES)

MODEL_FOR_BACKBONE_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_BACKBONE_MAPPING_NAMES)

MODEL_FOR_MASK_GENERATION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_MASK_GENERATION_MAPPING_NAMES)

MODEL_FOR_KEYPOINT_DETECTION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_KEYPOINT_DETECTION_MAPPING_NAMES
)

MODEL_FOR_KEYPOINT_MATCHING_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_KEYPOINT_MATCHING_MAPPING_NAMES)

MODEL_FOR_TEXT_ENCODING_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_TEXT_ENCODING_MAPPING_NAMES)

MODEL_FOR_TIME_SERIES_CLASSIFICATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_TIME_SERIES_CLASSIFICATION_MAPPING_NAMES
)

MODEL_FOR_TIME_SERIES_REGRESSION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_TIME_SERIES_REGRESSION_MAPPING_NAMES
)

MODEL_FOR_TIME_SERIES_PREDICTION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_TIME_SERIES_PREDICTION_MAPPING_NAMES
)

MODEL_FOR_IMAGE_TO_IMAGE_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_IMAGE_TO_IMAGE_MAPPING_NAMES)

MODEL_FOR_AUDIO_TOKENIZATION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_AUDIO_TOKENIZATION_NAMES)

MODEL_FOR_IMAGE_MATTING_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_IMAGE_MATTING_MAPPING_NAMES)
MODEL_FOR_NORMAL_ESTIMATION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_NORMAL_ESTIMATION_MAPPING_NAMES)
MODEL_FOR_POINTMAP_ESTIMATION_MAPPING = _LazyAutoMapping(
    CONFIG_MAPPING_NAMES, MODEL_FOR_POINTMAP_ESTIMATION_MAPPING_NAMES
)
MODEL_FOR_POSE_ESTIMATION_MAPPING = _LazyAutoMapping(CONFIG_MAPPING_NAMES, MODEL_FOR_POSE_ESTIMATION_MAPPING_NAMES)


class AutoModelForMaskGeneration(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_MASK_GENERATION_MAPPING


class AutoModelForKeypointDetection(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_KEYPOINT_DETECTION_MAPPING


class AutoModelForKeypointMatching(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_KEYPOINT_MATCHING_MAPPING


class AutoModelForTextEncoding(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TEXT_ENCODING_MAPPING


class AutoModelForImageToImage(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_IMAGE_TO_IMAGE_MAPPING


class AutoModel(_BaseAutoModelClass):
    _model_mapping = MODEL_MAPPING


AutoModel = auto_class_update(AutoModel)


class AutoModelForPreTraining(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_PRETRAINING_MAPPING


AutoModelForPreTraining = auto_class_update(AutoModelForPreTraining, head_doc="pretraining")


class AutoModelForCausalLM(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_CAUSAL_LM_MAPPING

    # override to give better return typehint
    @classmethod
    def from_pretrained(
        cls: type["AutoModelForCausalLM"],
        pretrained_model_name_or_path: str | os.PathLike[str],
        *model_args,
        **kwargs,
    ) -> "_BaseModelWithGenerate":
        return super().from_pretrained(pretrained_model_name_or_path, *model_args, **kwargs)


AutoModelForCausalLM = auto_class_update(AutoModelForCausalLM, head_doc="causal language modeling")


class AutoModelForMaskedLM(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_MASKED_LM_MAPPING


AutoModelForMaskedLM = auto_class_update(AutoModelForMaskedLM, head_doc="masked language modeling")


class AutoModelForSeq2SeqLM(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_SEQ_TO_SEQ_CAUSAL_LM_MAPPING


AutoModelForSeq2SeqLM = auto_class_update(
    AutoModelForSeq2SeqLM,
    head_doc="sequence-to-sequence language modeling",
    checkpoint_for_example="google-t5/t5-base",
)


class AutoModelForSequenceClassification(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_SEQUENCE_CLASSIFICATION_MAPPING


AutoModelForSequenceClassification = auto_class_update(
    AutoModelForSequenceClassification, head_doc="sequence classification"
)


class AutoModelForQuestionAnswering(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_QUESTION_ANSWERING_MAPPING


AutoModelForQuestionAnswering = auto_class_update(AutoModelForQuestionAnswering, head_doc="question answering")


class AutoModelForTableQuestionAnswering(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TABLE_QUESTION_ANSWERING_MAPPING


AutoModelForTableQuestionAnswering = auto_class_update(
    AutoModelForTableQuestionAnswering,
    head_doc="table question answering",
    checkpoint_for_example="google/tapas-base-finetuned-wtq",
)


class AutoModelForVisualQuestionAnswering(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_VISUAL_QUESTION_ANSWERING_MAPPING


AutoModelForVisualQuestionAnswering = auto_class_update(
    AutoModelForVisualQuestionAnswering,
    head_doc="visual question answering",
    checkpoint_for_example="dandelin/vilt-b32-finetuned-vqa",
)


class AutoModelForDocumentQuestionAnswering(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_DOCUMENT_QUESTION_ANSWERING_MAPPING


AutoModelForDocumentQuestionAnswering = auto_class_update(
    AutoModelForDocumentQuestionAnswering,
    head_doc="document question answering",
    checkpoint_for_example='impira/layoutlm-document-qa", revision="52e01b3',
)


class AutoModelForTokenClassification(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TOKEN_CLASSIFICATION_MAPPING


AutoModelForTokenClassification = auto_class_update(AutoModelForTokenClassification, head_doc="token classification")


class AutoModelForMultipleChoice(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_MULTIPLE_CHOICE_MAPPING


AutoModelForMultipleChoice = auto_class_update(AutoModelForMultipleChoice, head_doc="multiple choice")


class AutoModelForNextSentencePrediction(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_NEXT_SENTENCE_PREDICTION_MAPPING


AutoModelForNextSentencePrediction = auto_class_update(
    AutoModelForNextSentencePrediction, head_doc="next sentence prediction"
)


class AutoModelForImageClassification(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_IMAGE_CLASSIFICATION_MAPPING


AutoModelForImageClassification = auto_class_update(AutoModelForImageClassification, head_doc="image classification")


class AutoModelForZeroShotImageClassification(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_ZERO_SHOT_IMAGE_CLASSIFICATION_MAPPING


AutoModelForZeroShotImageClassification = auto_class_update(
    AutoModelForZeroShotImageClassification, head_doc="zero-shot image classification"
)


class AutoModelForImageSegmentation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_IMAGE_SEGMENTATION_MAPPING


AutoModelForImageSegmentation = auto_class_update(AutoModelForImageSegmentation, head_doc="image segmentation")


class AutoModelForSemanticSegmentation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_SEMANTIC_SEGMENTATION_MAPPING


AutoModelForSemanticSegmentation = auto_class_update(
    AutoModelForSemanticSegmentation, head_doc="semantic segmentation"
)


class AutoModelForTimeSeriesPrediction(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TIME_SERIES_PREDICTION_MAPPING


AutoModelForTimeSeriesPrediction = auto_class_update(
    AutoModelForTimeSeriesPrediction, head_doc="time-series prediction"
)


class AutoModelForUniversalSegmentation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_UNIVERSAL_SEGMENTATION_MAPPING


AutoModelForUniversalSegmentation = auto_class_update(
    AutoModelForUniversalSegmentation, head_doc="universal image segmentation"
)


class AutoModelForInstanceSegmentation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_INSTANCE_SEGMENTATION_MAPPING


AutoModelForInstanceSegmentation = auto_class_update(
    AutoModelForInstanceSegmentation, head_doc="instance segmentation"
)


class AutoModelForObjectDetection(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_OBJECT_DETECTION_MAPPING


AutoModelForObjectDetection = auto_class_update(AutoModelForObjectDetection, head_doc="object detection")


class AutoModelForZeroShotObjectDetection(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_ZERO_SHOT_OBJECT_DETECTION_MAPPING


AutoModelForZeroShotObjectDetection = auto_class_update(
    AutoModelForZeroShotObjectDetection, head_doc="zero-shot object detection"
)


class AutoModelForDepthEstimation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_DEPTH_ESTIMATION_MAPPING


AutoModelForDepthEstimation = auto_class_update(AutoModelForDepthEstimation, head_doc="depth estimation")


class AutoModelForTextRecognition(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TEXT_RECOGNITION_MAPPING


AutoModelForTextRecognition = auto_class_update(AutoModelForTextRecognition, head_doc="text recognition")


class AutoModelForTableRecognition(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TABLE_RECOGNITION_MAPPING


AutoModelForTableRecognition = auto_class_update(AutoModelForTableRecognition, head_doc="table recognition")


class AutoModelForVideoClassification(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_VIDEO_CLASSIFICATION_MAPPING


AutoModelForVideoClassification = auto_class_update(AutoModelForVideoClassification, head_doc="video classification")


class AutoModelForImageTextToText(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING

    # override to give better return typehint
    @classmethod
    def from_pretrained(
        cls: type["AutoModelForImageTextToText"],
        pretrained_model_name_or_path: str | os.PathLike[str],
        *model_args,
        **kwargs,
    ) -> "_BaseModelWithGenerate":
        return super().from_pretrained(pretrained_model_name_or_path, *model_args, **kwargs)


AutoModelForImageTextToText = auto_class_update(AutoModelForImageTextToText, head_doc="image-text-to-text modeling")


class AutoModelForMultimodalLM(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_MULTIMODAL_LM_MAPPING


AutoModelForMultimodalLM = auto_class_update(AutoModelForMultimodalLM, head_doc="multimodal generation")


class AutoModelForAudioClassification(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_AUDIO_CLASSIFICATION_MAPPING


AutoModelForAudioClassification = auto_class_update(AutoModelForAudioClassification, head_doc="audio classification")


class AutoModelForCTC(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_CTC_MAPPING


AutoModelForCTC = auto_class_update(AutoModelForCTC, head_doc="connectionist temporal classification")


class AutoModelForRNNT(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_RNNT_MAPPING


AutoModelForRNNT = auto_class_update(AutoModelForRNNT, head_doc="RNN transducer")


class AutoModelForTDT(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TDT_MAPPING


AutoModelForTDT = auto_class_update(AutoModelForTDT, head_doc="token-and-duration transducer")


class AutoModelForSpeechSeq2Seq(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_SPEECH_SEQ_2_SEQ_MAPPING


AutoModelForSpeechSeq2Seq = auto_class_update(
    AutoModelForSpeechSeq2Seq, head_doc="sequence-to-sequence speech-to-text modeling"
)


class AutoModelForAudioFrameClassification(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_AUDIO_FRAME_CLASSIFICATION_MAPPING


AutoModelForAudioFrameClassification = auto_class_update(
    AutoModelForAudioFrameClassification, head_doc="audio frame (token) classification"
)


class AutoModelForAudioXVector(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_AUDIO_XVECTOR_MAPPING


class AutoModelForTextToSpectrogram(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TEXT_TO_SPECTROGRAM_MAPPING


class AutoModelForTextToWaveform(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_TEXT_TO_WAVEFORM_MAPPING


class AutoBackbone(_BaseAutoBackboneClass):
    _model_mapping = MODEL_FOR_BACKBONE_MAPPING


AutoModelForAudioXVector = auto_class_update(AutoModelForAudioXVector, head_doc="audio retrieval via x-vector")


class AutoModelForMaskedImageModeling(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_MASKED_IMAGE_MODELING_MAPPING


AutoModelForMaskedImageModeling = auto_class_update(AutoModelForMaskedImageModeling, head_doc="masked image modeling")


class AutoModelForAudioTokenization(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_AUDIO_TOKENIZATION_MAPPING


AutoModelForAudioTokenization = auto_class_update(
    AutoModelForAudioTokenization, head_doc="audio tokenization through codebooks"
)


class AutoModelForImageMatting(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_IMAGE_MATTING_MAPPING


AutoModelForImageMatting = auto_class_update(AutoModelForImageMatting, head_doc="image matting")


class AutoModelForNormalEstimation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_NORMAL_ESTIMATION_MAPPING


AutoModelForNormalEstimation = auto_class_update(AutoModelForNormalEstimation, head_doc="normal estimation")


class AutoModelForPointmapEstimation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_POINTMAP_ESTIMATION_MAPPING


AutoModelForPointmapEstimation = auto_class_update(AutoModelForPointmapEstimation, head_doc="pointmap estimation")


class AutoModelForPoseEstimation(_BaseAutoModelClass):
    _model_mapping = MODEL_FOR_POSE_ESTIMATION_MAPPING


AutoModelForPoseEstimation = auto_class_update(AutoModelForPoseEstimation, head_doc="pose estimation")


__all__ = [
    "MODEL_FOR_AUDIO_CLASSIFICATION_MAPPING",
    "MODEL_FOR_AUDIO_FRAME_CLASSIFICATION_MAPPING",
    "MODEL_FOR_AUDIO_TOKENIZATION_MAPPING",
    "MODEL_FOR_AUDIO_XVECTOR_MAPPING",
    "MODEL_FOR_BACKBONE_MAPPING",
    "MODEL_FOR_CAUSAL_IMAGE_MODELING_MAPPING",
    "MODEL_FOR_CAUSAL_LM_MAPPING",
    "MODEL_FOR_CTC_MAPPING",
    "MODEL_FOR_RNNT_MAPPING",
    "MODEL_FOR_TDT_MAPPING",
    "MODEL_FOR_DOCUMENT_QUESTION_ANSWERING_MAPPING",
    "MODEL_FOR_DEPTH_ESTIMATION_MAPPING",
    "MODEL_FOR_NORMAL_ESTIMATION_MAPPING",
    "MODEL_FOR_POINTMAP_ESTIMATION_MAPPING",
    "MODEL_FOR_IMAGE_MATTING_MAPPING",
    "MODEL_FOR_TEXT_RECOGNITION_MAPPING",
    "MODEL_FOR_TABLE_RECOGNITION_MAPPING",
    "MODEL_FOR_IMAGE_CLASSIFICATION_MAPPING",
    "MODEL_FOR_IMAGE_MAPPING",
    "MODEL_FOR_IMAGE_SEGMENTATION_MAPPING",
    "MODEL_FOR_IMAGE_TO_IMAGE_MAPPING",
    "MODEL_FOR_POSE_ESTIMATION_MAPPING",
    "MODEL_FOR_KEYPOINT_DETECTION_MAPPING",
    "MODEL_FOR_KEYPOINT_MATCHING_MAPPING",
    "MODEL_FOR_INSTANCE_SEGMENTATION_MAPPING",
    "MODEL_FOR_MASKED_IMAGE_MODELING_MAPPING",
    "MODEL_FOR_MASKED_LM_MAPPING",
    "MODEL_FOR_MASK_GENERATION_MAPPING",
    "MODEL_FOR_MULTIPLE_CHOICE_MAPPING",
    "MODEL_FOR_NEXT_SENTENCE_PREDICTION_MAPPING",
    "MODEL_FOR_OBJECT_DETECTION_MAPPING",
    "MODEL_FOR_PRETRAINING_MAPPING",
    "MODEL_FOR_QUESTION_ANSWERING_MAPPING",
    "MODEL_FOR_SEMANTIC_SEGMENTATION_MAPPING",
    "MODEL_FOR_SEQ_TO_SEQ_CAUSAL_LM_MAPPING",
    "MODEL_FOR_SEQUENCE_CLASSIFICATION_MAPPING",
    "MODEL_FOR_SPEECH_SEQ_2_SEQ_MAPPING",
    "MODEL_FOR_TABLE_QUESTION_ANSWERING_MAPPING",
    "MODEL_FOR_TEXT_ENCODING_MAPPING",
    "MODEL_FOR_TEXT_TO_WAVEFORM_MAPPING",
    "MODEL_FOR_TEXT_TO_SPECTROGRAM_MAPPING",
    "MODEL_FOR_TIME_SERIES_PREDICTION_MAPPING",
    "MODEL_FOR_TOKEN_CLASSIFICATION_MAPPING",
    "MODEL_FOR_UNIVERSAL_SEGMENTATION_MAPPING",
    "MODEL_FOR_VIDEO_CLASSIFICATION_MAPPING",
    "MODEL_FOR_RETRIEVAL_MAPPING",
    "MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING",
    "MODEL_FOR_MULTIMODAL_LM_MAPPING",
    "MODEL_FOR_VISUAL_QUESTION_ANSWERING_MAPPING",
    "MODEL_MAPPING",
    "MODEL_FOR_ZERO_SHOT_IMAGE_CLASSIFICATION_MAPPING",
    "MODEL_FOR_ZERO_SHOT_OBJECT_DETECTION_MAPPING",
    "MODEL_FOR_TIME_SERIES_CLASSIFICATION_MAPPING",
    "MODEL_FOR_TIME_SERIES_REGRESSION_MAPPING",
    "AutoModel",
    "AutoBackbone",
    "AutoModelForAudioClassification",
    "AutoModelForAudioFrameClassification",
    "AutoModelForAudioTokenization",
    "AutoModelForAudioXVector",
    "AutoModelForCausalLM",
    "AutoModelForCTC",
    "AutoModelForRNNT",
    "AutoModelForTDT",
    "AutoModelForDepthEstimation",
    "AutoModelForTextRecognition",
    "AutoModelForTableRecognition",
    "AutoModelForImageClassification",
    "AutoModelForImageSegmentation",
    "AutoModelForImageToImage",
    "AutoModelForInstanceSegmentation",
    "AutoModelForKeypointDetection",
    "AutoModelForKeypointMatching",
    "AutoModelForMaskGeneration",
    "AutoModelForTextEncoding",
    "AutoModelForMaskedImageModeling",
    "AutoModelForMaskedLM",
    "AutoModelForMultipleChoice",
    "AutoModelForMultimodalLM",
    "AutoModelForNextSentencePrediction",
    "AutoModelForObjectDetection",
    "AutoModelForPreTraining",
    "AutoModelForQuestionAnswering",
    "AutoModelForSemanticSegmentation",
    "AutoModelForSeq2SeqLM",
    "AutoModelForSequenceClassification",
    "AutoModelForSpeechSeq2Seq",
    "AutoModelForTableQuestionAnswering",
    "AutoModelForTextToSpectrogram",
    "AutoModelForTextToWaveform",
    "AutoModelForTimeSeriesPrediction",
    "AutoModelForTokenClassification",
    "AutoModelForUniversalSegmentation",
    "AutoModelForVideoClassification",
    "AutoModelForVisualQuestionAnswering",
    "AutoModelForDocumentQuestionAnswering",
    "AutoModelForZeroShotImageClassification",
    "AutoModelForZeroShotObjectDetection",
    "AutoModelForImageTextToText",
    "AutoModelForImageMatting",
    "AutoModelForNormalEstimation",
    "AutoModelForPointmapEstimation",
    "AutoModelForPoseEstimation",
]
